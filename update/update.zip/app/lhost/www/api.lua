local utils     = require('utils')
local path 	    = require('path')
local conf      = require('ext/conf')
local json      = require('json')
local fs        = require('fs')
local thread    = require('thread')
local querystring = require('querystring')
local rpc       = require('vision/express/rpc')

-- 通过 cmdline 解析出相关的应用的名称
local function appGetName(cmdline)
    local _, _, appName = cmdline:find('lnode.+/([%w]+)/init.lua')

    if (not appName) then
        _, _, appName = cmdline:find('lnode.+/lpm%S([%w]+)%Sstart')
    end

    if (not appName) then
        _, _, appName = cmdline:find('lnode.+/lpm%Sstart%S([%w]+)')
    end    

    return appName
end

-- 返回包含所有正在运行中的应用进程信息的数组
-- @return {Array} 返回 [{ name = '...', pid = ... }, ... ]
local function appProcList()
    local list = {}
    local count = 0

    local files = fs.readdirSync('/proc') or {}
    if (not files) or (#files <= 0) then
        print('This command only support Linux!')
        return
    end

    for _, file in ipairs(files) do
        local pid = tonumber(file)
        if (not pid) then
            goto continue
        end

        local filename = path.join('/proc', file, 'cmdline')
        if not fs.existsSync(filename) then
            goto continue
        end

        local cmdline = fs.readFileSync(filename) or ''
        local name = appGetName(cmdline)
        if (name) then
            table.insert(list, {name = name, pid = pid})
            count = count + 1
        end

        ::continue::
    end

    return list, count
end

local function on_status(request, response)
    local method    = 'status'
        
    local list = appProcList()

    local result = { applications = list }
    response:json(result)
end

local function do_api(request, response, onEnd)
    local api = request.api

    if (api == '/status') then
        on_status(request, response)

    else
        response:sendStatus(400, "No `api` parameters specified!")
    end
end

request.params  = querystring.parse(request.uri.query) or {}
request.api     = request.params['api']
do_api(request, response)

return true
