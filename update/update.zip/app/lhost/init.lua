local app       = require('app')
local utils     = require('utils')
local path      = require('path')
local fs        = require('fs')

-------------------------------------------------------------------------------
-- 

-- 通过 cmdline 解析出相关的应用的名称
local function appGetName(cmdline)
    local _, _, appName = cmdline:find('lnode.+/([%w]+)/init.lua')

    if (not appName) then
        _, _, appName = cmdline:find('lnode.+/lpm%S([%w]+)%Sstart')
    end

    if (not appName) then
        _, _, appName = cmdline:find('lnode.+/lpm%Sstart%S([%w]+)')
    end    

    return appName
end

local LHOST_LIST_FILE = '/tmp/lhost.list'

local function appHostList()
    local filedata = fs.readFileSync(LHOST_LIST_FILE)
    local names = {}
    local count = 0

    if (not filedata) then
        return names, count, filedata
    end

    local list = filedata:split("\n")
    for _, item in ipairs(list) do
        if (#item > 0) then
            local filename = path.join(app.rootPath, 'app', item)
            --print(filename, app.rootPath)
            if fs.existsSync(filename) then
                names[item] = item
                count = count + 1
            end
        end
    end
    
    return names, count, filedata
end

-- 返回包含所有正在运行中的应用进程信息的数组
-- @return {Array} 返回 [{ name = '...', pid = ... }, ... ]
local function appProcList()
    local list = {}
    local count = 0

    local files = fs.readdirSync('/proc') or {}
    if (not files) or (#files <= 0) then
        print('This command only support Linux!')
        return
    end

    for _, file in ipairs(files) do
        local pid = tonumber(file)
        if (not pid) then
            goto continue
        end

        local filename = path.join('/proc', file, 'cmdline')
        if not fs.existsSync(filename) then
            goto continue
        end

        local cmdline = fs.readFileSync(filename) or ''
        local name = appGetName(cmdline)
        if (name) then
            table.insert(list, {name = name, pid = pid})
            count = count + 1
        end

        ::continue::
    end

    return list, count
end

local function appEnable(newNames, enable)
    local names, count, oldData = appHostList()

    for _, name in ipairs(newNames) do
        if (enable) then
            local filename = path.join(app.rootPath, 'app', name)
            if (fs.existsSync(filename)) then
                names[name] = name
            end

        else
            names[name] = nil
        end
    end
    
    -- save to file
    local list = {}
    for _, item in pairs(names) do
        list[#list + 1] = item
    end

    table.sort(list, function(a, b)
        return tostring(a) < tostring(b)
    end)

    list[#list + 1] = ''

    local fileData = table.concat(list, "\n")
    if (oldData == fileData) then
        return fileData
    end

    print("Updating services table...")
    print("  " .. table.concat(list, " ") .. "\n")

    local tempname = LHOST_LIST_FILE .. ".tmp"
    if fs.writeFileSync(tempname, fileData) then
        os.remove(LHOST_LIST_FILE)
        os.rename(tempname, LHOST_LIST_FILE)
    end

    return fileData
end

-------------------------------------------------------------------------------
-- exports

local exports = {}

-- 检查应用进程，自动重启意外退出的应用程序
function exports.check()
    local names = appHostList()
    local procs = appProcList()

    for _, proc in ipairs(procs) do
        names[proc.name] = nil
    end

    for name, pid in pairs(names) do
        console.log('restart:', name)
        os.execute("lpm daemon " .. name)
    end
end

-- 在后台运行当前应用
function exports.daemon()
    app.daemon()
end

-- 不允许指定名称的应用在后台一直运行
function exports.disable(...)
    local names = table.pack(...)
    if (#names < 1) then
        exports.help()
        return
    end

    appEnable(names, false)
end

-- 允许指定名称的应用在后台一直运行
function exports.enable(...)
    local names = table.pack(...)
    if (#names < 1) then
        exports.help()
        return
    end

    appEnable(names, true)
end

function exports.help()
    print([[
        
usage: lpm lhost <command> [args]

Node.lua application daemon manager

running file:
    
- /tmp/lhost.list

Available command:

- check              Check all application daemon status
- disable [name...]  Disable application daemon
- enable [name...]   Enable application daemon
- help               Display help information
- start [interval]   Start lhost
- status             Show status

Available top command:

- lpm start [name]   Start the application
- lpm stop [name]    Stop the application
- lpm restart all    Restart all application
- lpm restart [name] Restart the application
- lpm kill [name]    Kill the application only
- lpm ps             List all running application

]])
end

-- 杀掉指定名称的应用的所有进程
function exports.kill(name)
    if (not name) then
        print('APP name expected!')
        exports.help()
        return
    end

    local found = nil

    local list = appProcList()
    if (not list) or (#list < 1) then
        return
    end

    for _, proc in ipairs(list) do
        if (proc.name == name) then
            local cmd = "kill " .. proc.pid
            print("kill (" .. name .. ") " .. proc.pid)
            os.execute(cmd)

            found = pid
        end
    end
end

-- 列出所有正在运行的应用程序
function exports.list()
    local names = appHostList()
    local list  = appProcList()
    if (not list) or (#list < 1) then
        print('No matching application process were found!')
        return
    end

    local services = {}
    for name, value in pairs(names) do
        services[name] = { name = name }
    end

    for _, proc in ipairs(list) do
        local service = services[proc.name]
        if (not service) then
            service = { name = proc.name }
            services[proc.name] = service
        end

        if (not service.pids) then
            service.pids = {}
        end

        service.pids[#service.pids + 1] = tostring(proc.pid)
    end

    list = {}
    for name, service in pairs(services) do
        list[#list + 1] = service
    end 

    table.sort(list, function(a, b) 
        return tostring(a.name) < tostring(b.name) 
    end) 

    local cols = { 10, 16, 24 }

    app.tableDivision(cols)
    app.tableLine(cols, "status", "name", "pids")
    app.tableDivision(cols)
    for _, proc in ipairs(list) do
        local status = '[   ]'
        if (proc.pids) then status = '[ + ]' end
        local pids = proc.pids or {}
        app.tableLine(cols, status, proc.name, table.concat(pids, ","))
    end
    app.tableDivision(cols)
end

-- 重启指定的名称的应用程序
function exports.restart(name)
    if (not name) then
        print('APP name expected!')
        exports.help()
        return

    else 
        os.execute('killall lnode; lpm start lhost')
        return
    end
    
    exports.kill(name)
    os.execute('lpm start ' .. name)
end

-- 启动应用进程守护程序
function exports.start(interval, ...)
    print("Start lhost...")

    local tmpdir = os.tmpdir or '/tmp'

    -- 检查是否有另一个进程正在更新系统
    local lockname = path.join(tmpdir, '/lhost.lock')
    local lockfd = fs.openSync(lockname, 'w+')
    local ret = fs.fileLock(lockfd, 'w')
    if (ret == -1) then
        print('The lhost is lock!')
        return
    end

    interval = interval or 3
    setInterval(interval * 1000, function()
        exports.check()
    end)

    process:on("exit", function()
        fs.fileLock(lockfd, 'u')
    end)
end

-- 杀掉指定名称的进程，并阻止其在后台继续运行
function exports.stop(name)
    if (name) then
        appEnable({name}, false)
        exports.kill(name)

    else
        exports.kill('lhost')
    end
end

app(exports)
