local fs 		= require('fs')
local Path 		= require('path')
local json   	= require('json')
local path   	= require('path')
local utils 	= require('utils')
local conf  	= require('ext/conf')

local pprint = utils.pprint
local exports = {}

local function getRootPath()
	return conf.rootPath
end

 local function getAppPath()
 	local appPath = path.join(getRootPath(), "app")
	if (not fs.existsSync(appPath)) then
		appPath = path.join(path.dirname(getRootPath()), "app")
	end

	return appPath
 end

local function getDeviceJson(basePath)
	local filename = path.join(basePath, "device.json")
	local data = fs.readFileSync(filename)
	return data and json.parse(data)
end


local function putJson(pathname,json)
	local fn = path.join(pathname, 'device.json')
	pprint(fn)
    local fd = fs.openSync(fn, 'w')
    written = fs.writeSync(fd, -1, json)
    fs.closeSync(fd)
    local data = fs.readFileSync(fn)
    -- pprint(data)
    return written
end

function putDevice(uid,deviceId,deviceKey)
	local devices,filepath = getDevics()
	for i = 1, #devices do
			local device = devices[i]
			if(uid == device.attributes.uid)
				then
				-- pprint('in')
				device.id = deviceId
				device.key = deviceKey
				local stringDevice = json.stringify(device)
				putJson(filepath[i],stringDevice)
				return 0
			end
		end
	return -1
end

function getDevics()
	local devices = {}
	local filepath = {}

	local appPath = path.join(getAppPath())
	-- print(appPath)

	local files = nil
	if (fs.existsSync(appPath)) then
		files = fs.readdirSync(appPath)
	end

	local index = 1
	if (files) then
		for i = 1, #files do
			local file = files[i]
			local filename  = path.join(appPath, file)
			local info 		= getDeviceJson(filename) or nil
			if(info ~= nil)
				then
				devices[index] = info
				filepath[index] = filename
				index = index + 1
			end
		end
	end

	return devices,filepath
end

-- local x = putJson('/usr/local/lnode/app/sensor','testhsp')
-- local x = putDevice('123','123','456')
-- print(x)
-- local devices,filepath = getDevics()
-- pprint(devices,filepath)
-- local device = {}
-- device.hao = 'hao'
-- device.good = 'good'
-- pprint(device)
-- local string = json.stringify(device)
-- pprint(string)
-- local jsonObject =  json.parse(string)
-- pprint(jsonObject)
function exports.put(uid,deviceId,deviceKey)
	return putDevice(uid,deviceId,deviceKey)
end

function exports.get()
	return getDevics()
end
return exports
