local app       = require('app')
local fs        = require('fs')
local express   = require('vision/express')
local request   = require('vision/express/request')
local server    = require('vision/ssdp/server')
local utils     = require('utils')
local path      = require('path')
local json      = require('json')
local conf      = require('ext/conf')

local device    = require('./device')

local WEB_PORT  = 9100

local ssdpServer = nil

local exports = {}

local deviceInfo

local function getRootPath()
    return conf.rootPath
end

local function getSystemTarget()
    local platform = os.platform()
    local arch = os.arch()

    if (platform == 'win32') then
        return 'win'

    elseif (platform == 'darwin') then
        return 'macos'
    end

    local filename = getRootPath() .. '/package.json'
    local packageInfo = json.parse(fs.readFileSync(filename)) or {}
    local target = packageInfo.target or 'linux'
    target = target:trim()
    return target
end

local function loadDeviceInfo()
    if (deviceInfo) then
        return
    end

    deviceInfo = {}

    local profile = conf('lpm')
    deviceInfo.model        = profile:get('device.deviceModel') or ''
    deviceInfo.type         = profile:get('device.deviceType') or ''
    deviceInfo.serialNumber = profile:get('device.deviceId') or ''
    deviceInfo.manufacturer = profile:get('device.manufacturer') or 'CMPP'
    deviceInfo.udn          = 'uuid:' .. deviceInfo.serialNumber
    deviceInfo.target       = getSystemTarget()
    deviceInfo.version      = process.version
end

-------------------------------------------------------------------------------
-- exports

local function getDeviceDescribe()
    loadDeviceInfo()

    local describe = {}
    describe.version    = 1

    local device = {}
    describe.device     = device
    device.manufacturer = deviceInfo.manufacturer
    device.model        = deviceInfo.model
    device.name         = deviceInfo.model
    device.serialNumber = deviceInfo.serialNumber
    device.type         = deviceInfo.type
    device.udn          = deviceInfo.udn
    device.target       = deviceInfo.target
    device.version      = deviceInfo.version
    device.url          = 'http://192.168.77.1:80'

    local serviceList = {}
    device.serviceList = serviceList

    local service = {}
    serviceList[1] = service

    service.type = 'Hygrothermograph:1'
    service.url  = 'hygrothermograph.json'

    return describe
end 

local function start_web_server()
    local dirname = utils.dirname()
    local root = path.join(dirname, 'www')
    local app = express({ root = root })

    app:on('error', function(err) 
        print('Express', err)
        process:exit()
    end)

    app:get("/device.json", function(request, response)
        local rsp = {}
        local devices = device.get()
        rsp.code = 200
        rsp.result = 'success'
        rsp.api = '/devices.json'
        rsp.data = devices
        response:json(rsp)
        -- response:json(getDeviceDescribe())
    end)

    app:get("/device", function(request, response)
        response:json(getDeviceDescribe())
    end)

    app:get("/connect", function(request, response)
        local result = { ret = 0 }
        -- TODO: connect
        response:json(result)
    end)

    app:get("/disconnect", function(request, response)
        local result = { ret = 0 }
        -- TODO: disconnect
        response:json(result)
    end)

    app:post("/install", function(request, response)
        print('Upload complete.')

        local data = request.body
        local filename = '/tmp/install.zip'
        if (not data) then
            response:json({ ret = -1, error = 'Bad request' })
            return
        end

        local rootPath = nil
        print('file', filename, #data)

        local query = request.query or {}
        local dest = query.dest
        if (dest ~= 'global') then
            rootPath = path.dirname(os.tmpname())
        end

        os.remove(filename)
        fs.writeFileSync(filename, data)

        local upgrade = require('ext/upgrade')
        upgrade.installFile(filename, rootPath, function(err, checkInfo)
            local result = { ret = 0 }

            if (checkInfo.faileds and checkInfo.faileds > 0) then
                result.ret = -1
                result.error = string.format('(%d) error has occurred in the upgrade!', checkInfo.faileds)
            end

            response:json(result)
        end)
    end)

    app:post("/remove", function(request, response)
        local result = { ret = 0 }
        -- TODO: disconnect
        response:json(result)
    end)   

    app:post("/upgrade", function(request, response)
        print('Upload complete.')

        local data = request.body
        local filename = '/tmp/update.zip'
        if (not data) then
            response:json({ ret = -1, error = 'Bad request' })
            return
        end

        local query = request.query or {}
        local rootPath = query.rootPath
        print('file', filename, #data)

        os.remove(filename)
        fs.writeFileSync(filename, data)

        local upgrade = require('ext/upgrade')
        upgrade.upgradeFile(filename, rootPath, function(err, checkInfo)
            local result = { ret = 0 }

            if (checkInfo.faileds and checkInfo.faileds > 0) then
                result.ret = -1
                result.error = string.format('(%d) error has occurred in the upgrade!', checkInfo.faileds)
            end

            response:json(result)
        end)
    end)

    app:post("/register", function(request, response)
        --console.log(request)

        console.log('body', request.body)
        local body  = json.parse(request.body)
        local result = device.put(body.uid,body.id,body.key)
        if(result == 0)
            then
            response:send('{"code":200,"api":"register","result":"success"}')
        else
            response:send('{"code":400,"api":"register","result":"fault"}')
        end
    end)

    app:listen(WEB_PORT)
end

-------------------------------------------------------------------------------
-- exports

function exports.help()
    app.usage(utils.dirname())

    print([[
Available command:

- scan          Scan all SSDP device or services
- start         Start SSDP server
- view [ip]     View SSDP device information
]])

end

function exports.scan(serviceType, timeout)
    local client = require('vision/ssdp/client')
    local list = {}

    print("Start scaning...")
    local ssdpClient = client({}, function(response, rinfo)
        if (list[rinfo.ip]) then
            return
        end

        local headers   = response.headers
        local item      = {}
        item.remote     = rinfo
        item.usn        = headers["usn"] or ''

        list[rinfo.ip] = item
        print('- ' .. utils.color('string') .. rinfo.ip .. '@' .. item.usn, utils.color())
    end)

    -- search for a service type 
    serviceType = serviceType or 'urn:schemas-upnp-org:service:cmpp-iot'
    ssdpClient:search(serviceType)

    local scanCount = 0
    local scanTimer = nil
    local scanMaxCount = timeout or 3

    scanTimer = setInterval(1000, function()
        ssdpClient:search(serviceType)
        print(".\r")

        scanCount = scanCount + 1
        if (scanCount >= scanMaxCount) then
            clearInterval(scanTimer)
            scanTimer = nil
            
            ssdpClient:stop()
            print("End scaning...")
        end
    end)
end

function exports.start()
    loadDeviceInfo()
    
    local server = require('vision/ssdp/server')
    exports.ssdpServer = server({ udn = deviceInfo.udn })

    local localAddress = exports.ssdpServer:getLocalAddress() or '0.0.0.0'
    local localtion = "http://" .. localAddress .. ':' .. WEB_PORT .. '/device.json'

    exports.ssdpServer.location = localtion

    start_web_server()
    print('SSDP server started.')
end

function exports.view(host)
    if (not host) then
        print('ssdp: Not enough arguments provided!')
        print('ssdp: Try `lpm ssdp help` for more information!')
        return
    end

    local url = "http://" .. host .. ":9100/device.json"
    request(url, function(err, response, data)
        --console.log(err, data)

        if (err) then
            print(err)
            return
        end

        data = json.parse(data) or {}
        console.log(data)
    end)
end

function exports.test()
    local server = require('vision/ssdp/server')
    exports.ssdpServer = server({})
end

app(exports)
