local utils     = require('utils')
local json      = require('json')
local conf      = require('ext/conf')
local request   = require('vision/express/request')
local lpm       = require('ext/lpm')

local querystring  = require('querystring')

local SDCP_DEFAULT_HOST = 'http://iot.sae-sz.com:4000'

local SDCP_HOST 		= 'sdcp.host'
local SDCP_CLIENT_ID 	= 'sdcp.client_id'
local SDCP_USERNAME 	= 'sdcp.username'
local SDCP_DEVICE_ID 	= 'sdcp.device_id'
local SDCP_DEVICE_KEY 	= 'sdcp.device_key'
local SDCP_GROUP_ID 	= 'sdcp.group_id'

-- http://iot.sae-sz.com/rockmongo/index.php?action=admin.index&host=0

-------------------------------------------------------------------------------
-- profile

local _profile = nil

local function loadProfile()
    if (_profile) then
        return _profile
    end

	_profile = conf('user')
    return _profile
end

-- 删除指定名称的配置参数项的值
local function del(name)
	local profile = loadProfile()
	if (profile:get(name)) then
		profile:set(name, nil)
		profile:commit()
	end
end

-- 打印指定名称的配置参数项的值
local function get(name)
	if (name) then
	    local profile = loadProfile()
		return profile:get(name)
	end
end

-- 设置指定名称的配置参数项的值
local function set(name, value)
	if (not name) then
		return
	end

	local profile = loadProfile()

    if (type(name) == 'table') then
        local count = 0
        for k, v in pairs(name) do
            local oldValue = profile:get(k)
            --print(k, v, oldValue)

            if (not oldValue) or (v ~= oldValue) then
                profile:set(k, v)

                count = count + 1
            end
        end

        if (count > 0) then
            profile:commit()
        end

    else 
    	if (not value) then
            return
        end

        local oldValue = profile:get(name)
        if (not oldValue) or (value ~= oldValue) then
            profile:set(name, value)
            profile:commit()
        end
    end
end

-------------------------------------------------------------------------------
-- publish

local function publish(clientId, content, callback)
    local mqttUrl = 'mqtt://iot.sae-sz.com:1883'
    local dataTopic = '/device/data'

    local onMessage = function(topic, payload)
		console.log(TAG, 'message', topic, payload)
	end

    local mqtt  = require('vision/mqtt')
    local options = { callback = onMessage, clientId = clientId }
	client = mqtt.connect(mqttUrl, options)
	client.debugEnabled = true

    local timeoutTimer = setTimeout(10 * 1000, function()
        print(TAG, 'send timeout!')
        client:close()
    end)

   	client:on('connect', function(connack)
        client:publish(dataTopic, content, { qos = 1 }, function(publish, err)
            if (timeoutTimer) then
                clearTimeout(timeoutTimer)
                timeoutTimer = nil
            end

            callback(publish, err)
            client:close()
	  	end)
	end)

	client:on('error', function(errInfo)
		console.log(TAG, 'event', 'error', errInfo)
	end)
end

-------------------------------------------------------------------------------
-- exports

local exports = {}

function exports.help()
	print([[
usage: lpm sdcp <command> [args]

where <command> is one of:

- login <username> <password> Login with user account
- logout Logout current device login session
- ping Ping IOT server state
- scan <timeout> Scan devices on LAN
- send <key> <value> Send data to IOT server
]])

end

--[[
这里使用的是用户的账号名和密码登录. 由服务器分配设备 ID 和密钥, 
密钥由设备妥善保存, 不要发布到网络上, 以后向服务器发送消息都需用这个密钥签名
服务器验证通过才接受这个设备的消息.
登录时可携带设备的客户端 ID 或之前用过的设备 ID, 如果这个 ID 的设备已经存在
就不为这个设备注册新的设备账号了.
--]]
function exports.login(username, password)
	local baseUrl = get(SDCP_HOST) or SDCP_DEFAULT_HOST
	local url = baseUrl .. '/device/login'
    --print('login', url)

	local params = {
        client_id = get(SDCP_CLIENT_ID) or '',
	    device_id = get(SDCP_DEVICE_ID) or '',
	    group_id  = get(SDCP_GROUP_ID)  or '',
	    username  = username or '',
        phone     = username or '',
	    password  = password or ''
    }
    url = url .. '?' .. querystring.stringify(params)
    --print('login', url)

	request(url, function(error, response, body)
		if (error) then
			print(error)
			return
		end

        local result = json.parse(body)
        if (not result) then
            print('response', response.statusCode, utils.dump(result))
            return
        end

        --print('response', response.statusCode, utils.dump(result))
        if (result.result) then
            print('result: ' .. tostring(result.result))
        end

		local data = result.data or {}

		local deviceId  = data.id
		local deviceKey = data.key

        if (deviceKey) then
            local params = {
                [SDCP_USERNAME]   = username,
                [SDCP_DEVICE_ID]  = deviceId,
                [SDCP_DEVICE_KEY] = deviceKey
            }

            set(params)
        end

		print('Finish! id: ' .. tostring(deviceId) .. ", key: " .. tostring(deviceKey))
	end)
end

--[[
从服务器注销这个设备, 重置设备的 密钥, 注销之后要再使用这个设备的账号则需要重新登录.

--]]
function exports.logout()
	local baseUrl = get(SDCP_HOST) or SDCP_DEFAULT_HOST
	local url = baseUrl .. '?api=/device/logout'
    print('logout', url)

    local timestamp = os.time()
    local device_key = get(SDCP_DEVICE_KEY) or 'test'
    local sign = utils.bin2hex(utils.md5(device_key .. ':' .. timestamp))

	local params = {
        client_id  = get(SDCP_CLIENT_ID)  or 'test',
	    username   = get(SDCP_USERNAME)   or 'test',
	    device_id  = get(SDCP_DEVICE_ID)  or 'test',
	    device_key = device_key,
        sign       = sign,
        timestamp  = timestamp

    }
    url = url .. '&' .. querystring.stringify(params)
    print('logout', url)

	request(url, function(error, response, body)
		if (error) then
			print(error)
			return
		end

        local result = json.parse(body) or {}
        print(response.statusCode, utils.dump(result))
	end)
end

--[[
检查和 IOT 服务器的连接状态, 则时也检测当前设备的登录状态
--]]
function exports.ping()
	local baseUrl = get(SDCP_HOST) or SDCP_DEFAULT_HOST
	local url = baseUrl .. '/ping'
    --print('ping', url)

    local timestamp = os.time()
    local device_key = get(SDCP_DEVICE_KEY) or 'test'
    local sign = utils.bin2hex(utils.md5(device_key .. ':' .. timestamp))

	local params = {
        client_id   = get(SDCP_CLIENT_ID)  or 'test',
	    username    = get(SDCP_USERNAME)   or 'test',
	    device_id   = get(SDCP_DEVICE_ID)  or 'test',
	    device_key  = device_key,
	    sign        = sign,
        timestamp   = timestamp
    }
    url = url .. '&' .. querystring.stringify(params)
    --print('ping', url)

	request(url, function(error, response, body)
		if (error) then
			print(error)
			return
		end

        local result = json.parse(body) or {}

        print('response', response.statusCode, utils.dump(result))
	end)
end

--[[
扫描设备
该命令会搜索当前网络中的设备。

注意，请确保开发机与设备连接的是同一个无线热点或有线网络，另外，这个操作
可能会时间稍长，需要略做等待。

@param timeout 搜索时间，默认为 10 秒。
]]
function exports.scan(timeout)
	local client = require('vision/ssdp/client')
	local list = {}

	print("Start scaning...")
	local ssdpClient = client({}, function(response, rinfo)
		if (list[rinfo.ip]) then
			return
		end

        local headers   = response.headers
		local item      = {}
		item.remote     = rinfo
		item.usn 		= headers["usn"] or ''
		item.st 		= headers["st"]
		item.location 	= headers["location"]

		list[rinfo.ip] = item
		--pprint(item)

		print('- ' .. utils.color('string') .. rinfo.ip .. '@' .. item.usn, utils.color())
	end)

    -- get a list of all services on the network 
	-- ssdpClient:search('ssdp:all')

    -- search for a service type 
	local serviceType = 'urn:schemas-upnp-org:service:cmpp-iot'
	ssdpClient:search(serviceType)

	local scanTimer = setInterval(1000, function()
        ssdpClient:search(serviceType)
		_print(".\r")
	end)

	setTimeout((timeout or 3) * 1000, function()
		clearInterval(scanTimer)
		scanTimer = nil

		ssdpClient:stop()
		print("Finish!")
	end)
end

function exports.send(key, value)
    if (not key) or (not value) then
        exports.help()
        return
    end

    local TAG = 'mqtt'
    local seq = 1
    local timestamp = os.time()
    local data = {
        reported = { [key] = value or ''},
        seq = seq,
        timestamp = timestamp
    }

    local device_key = get(SDCP_DEVICE_KEY) or 'test'
    local device_id  = get(SDCP_DEVICE_ID)  or 'test'
    local sign = utils.bin2hex(utils.md5(device_key .. ':' .. timestamp))

    local key = tostring(timestamp)
    local hash = utils.bin2hex(utils.md5(device_key .. key))

	local message = {
	    device_id   = device_id,
	    device_key  = device_key,
        sign        = sign,
        state       = {},
        key        = key,
        hash       = hash,
        version     = 10
    }

    table.insert(message.state, data)
    --console.log(message)

    local content = json.stringify(message)
    publish(device_id, content, function(publish, err)
        if (err) then
            print('MQTT message sent failed:')
            console.log(err)

        else
            print('MQTT message sent complete:')
            console.log(data)
        end
    end)
end

local function main(action, ...)
    local method = exports[action or 'help']
    if (method) then
        method(...)

	else
		exports.help()
	end
end

main(table.unpack(arg))

run_loop()
