
$matrix = {};
$matrix.mode = 0;

function OnMatrixMouseDown(event) {
	var event = event || window.event;
	var srcElement = event.srcElement || event.target;
	if (srcElement.className != 'selected') {
		srcElement.className = 'selected';
		$matrix.mode = 1;

	} else {
		srcElement.className = '';
		$matrix.mode = 2;
	}

	$('#' + $matrix.id).val(OnMatrixGet());
}

function OnMatrixMouseUp(event) {
	$matrix.mode = 0;
}

function OnMatrixMouseOut(event) {
	//$matrix.mode = 0;
}

function OnMatrixMouseMove(event) {
	var event = event || window.event;
	var srcElement = event.srcElement || event.target;

	if ($matrix.mode == 1) {
		if (srcElement.className != 'selected') {
			srcElement.className = 'selected';

			$('#' + $matrix.id).val(OnMatrixGet());
		}

	} else if ($matrix.mode == 2) {
		if (srcElement.className != '') {
			srcElement.className = '';

			$('#' + $matrix.id).val(OnMatrixGet());
		}
	}
}

function OnMatrixShow(blocks) {
	blocks = blocks || "";
	var tds = document.getElementsByName("matrix-cell");
	if (!tds || tds.length < 0) {
		return 0;
	}

	var tokens = {
		'0':0,  '1':1,  '2':2,  '3':3,  '4':4, 
		'5':5,  '6':6,  '7':7,  '8':8,  '9':9, 
		'A':10, 'B':11, 'C':12, 'D':13, 'E':14, 'F': 15, 
		'a':10, 'b':11, 'c':12, 'd':13, 'e':14, 'f': 15
	};

	var table = [];
	var index = 0;
	for (var i = 0; i < blocks.length; i++) {
		var ch = blocks.charAt(i);
		var item = tokens[ch] || 0;
		table[index++] = (item & 0x08) ? 1 : 0;
		table[index++] = (item & 0x04) ? 1 : 0;
		table[index++] = (item & 0x02) ? 1 : 0;
		table[index++] = (item & 0x01) ? 1 : 0;
	}

	for (var i = 0; i < tds.length; i++) {
		tds[i].className = table[i] ? "selected" : "";
	}
}

function OnMatrixWeekdayClick(weekday) {
	var tds = document.getElementsByName("matrix-cell");
	if (!tds || tds.length < 0) {
		return 0;
	}
	
	var checked = 0;
	var offset = weekday * 48;

	for (var i = 0; i < 48; i++) {
		if (!tds[i + offset].className) {
			checked = 1;
			break;
		}
	}

	for (var i = 0; i < 48; i++) {
		tds[i + offset].className = checked ? "selected" : "";
	}
}

function OnMatrixGet() {
	var tds = document.getElementsByName("matrix-cell");
	if (!tds || tds.length < 0) {
		return 0;
	}

	var blocks 	= "";
	var item 	= 0;
	var tokens 	= ['0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'];

	for (var i = 0; i < tds.length; i++) {
		var value = 0;
		if (tds[i].className) {
			value = 1;
			item += (value << (3 - (i % 4)));
		}

		if ((i % 4) == 3) {
			blocks += (tokens[item] || '0');
			item = 0;
		}
	}

	return blocks;
}

function OnMatrixClick(event) {
	$('#' + $matrix.id).val(OnMatrixGet());
}

function OnMatrixTouchMove(event) {
	var event = event || window.event;
	event.preventDefault();

	if ($matrix.mode == 0) {
		OnMatrixMouseDown(event);
	}

	OnMatrixMouseMove(event);
}

function ShowScheduleTable() {
	var html = '';

	var WEEKDAYS = [T("CalSun"), T("CalMon"), T("CalTue"), 
		T("CalWed"), T("CalThu"), T("CalFri"), T("CalSat")];

	var rows = 1;
	var cols = (24 / rows);

	html += '<table unselectable="on" onselectstart="return false;">';
	html += '<colgroup>';
	html += '<col/>';
	for (var i = 0; i < cols * 2; i++) {
		html += '<col id="col' + i + '" style="width:11px;"/>';
	}
	html += '</colgroup>';

	html += '<thead>';
	html += '<tr>';
	html += '<td onclick="OnMatrixMouseClick();">&nbsp;</td>';


	for (var i = 0; i < cols; i++) {
		if (i < (cols - 1)) {
			html += '<th colspan="2">' + i + '</th>';
		} else {
			html += '<td colspan="2">' + i + '</td>';
		}
	}

	html += '</tr>';
	html += '</thead>';

	html += '<tbody onmouseout="OnMatrixMouseOut();">';
	for (var weekday = 0; weekday < 7; weekday++) {

		for (var j = 0; j < rows; j++) {
			html += '<tr>';
			if (j == 0) {
				html += '<th class="matrix-weekday" onclick="OnMatrixWeekdayClick(' + weekday + ')" rowspan="';
				html += rows + '">' + WEEKDAYS[weekday] + '</th>';
			}

			cols = (24 / rows) * 2;
			for (var i = 0; i < cols; i++) {
				var title = Math.floor(i / 2) + j * 8;
				title += ":";
				title += (i % 2) ? "30" : "00";

				html += '<td id="matrix-cell" name="matrix-cell" class="" name="matrix-cell" title="' + title + '"';
				html += ' onmousedown="OnMatrixMouseDown();" onmouseup="OnMatrixMouseUp();"';
				html += ' onmousemove="OnMatrixMouseMove(event, this);"';
				html += ' ontouchmove="OnMatrixTouchMove();"></td>';
			}
			html += '</tr>';
		}
	}

	html += '</tbody>';
	html += '</table>';
	return html;
}
