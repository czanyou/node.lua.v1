--[[

Copyright 2014-2015 The Luvit Authors. All Rights Reserved.
Copyright 2016 The Node.lua Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS-IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

--]]
local meta = { }
meta.name        = "lnode/zlib"
meta.version     = "1.0.0"
meta.license     = "Apache 2"
meta.description = "zip lib"
meta.tags        = { "lnode", "zlib", "zip" }

local exports = { meta = meta }

local miniz = require('miniz')
local path  = require('path')
local fs    = require('fs')
local utils = require('utils')

local Error  = require('core').Error
local Object = require('core').Object

-------------------------------------------------------------------------------
-- Gzip

local Gzip = Object:extend()

function exports.createGzip(options)
	return Gzip:new(options)
end

-------------------------------------------------------------------------------
-- ZipBuilder

local ZipBuilder = Object:extend()
exports.ZipBuilder = ZipBuilder

function ZipBuilder:build(pathname, skipList)
    local basename = path.basename(pathname)
    local dirname  = path.dirname(pathname)

    local fileList = {}
    if (skipList) then
        print('list:', #skipList)
        for _, item in ipairs(skipList) do
            fileList[item.name] = item
        end
    end

    local filename = path.join(dirname, basename .. ".zip")
    local fd = fs.openSync(filename, "w", 511)
    if (not fd) then
        return filename .. ' open failed!'
    end

    local writer = miniz.new_writer()
    if (not writer) then
        fs.closeSync(fd)
        return -1
    end

    local _copy_directory, _copy_file, _copy_file_data, _get_file_info

    -----------------------------------------------------------

    function _copy_directory(basePath, subPath)
        local fullName = path.join(basePath, subPath)
        local files = fs.readdirSync(fullName)
        if (not files) then 
            return 
        end

        for i = 1, #files do
            local name = files[i]
            if (name:sub(1, 1) ~= ".") then
                _copy_file(basePath, subPath, name)
            end
        end
    end

    function _copy_file(basePath, subPath, name)
        local childPath = path.join(subPath, name)
        local fullPath  = path.join(basePath, childPath)
        
        local stat = _get_file_info(fullPath)
        if stat.type == "directory" then
            local dirname = childPath .. "/"
            dirname = ""..dirname:gsub('\\', '/')
            print("  adding: " .. utils.colorize("string", dirname))

            writer:add(dirname, "")
            _copy_directory(basePath, childPath)

        elseif stat.type == "file" then
            _copy_file_data(fullPath, childPath)
        end
    end

    function _copy_file_data(srcfile, destfile)
        local filedata = fs.readFileSync(srcfile)
        local filename = destfile:gsub('\\', '/')

        if (filedata) then
            local item = fileList[filename]
            if (item) then
                local md5sum = utils.bin2hex(utils.md5(filedata))
                if (item.md5sum == md5sum) then
                    --print(item.name)
                    return
                end
            end

            writer:add(filename, filedata, 9)
            print("  adding: " .. filename)
        end
    end

    function _get_file_info(filename)
        local statInfo, err = fs.statSync(filename)
        if (not statInfo) then 
            return nil, err 
        end

        return {
            type    = string.lower(statInfo.type),
            size    = statInfo.size,
            mtime   = statInfo.mtime,
        }
    end


    _copy_directory(pathname, "")

    -- finish
    local offset = nil
    fs.writeSync(fd, offset, writer:finalize())
    fs.closeSync(fd)

end

-------------------------------------------------------------------------------
-- ZipBuilder

local ZipReader = Object:extend()
exports.ZipReader = ZipReader



-------------------------------------------------------------------------------
-- exports

return exports
