--[[

Copyright 2016 The Node.lua Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS-IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

--]]

local fs 		= require('fs')
local path  	= require('path')
local timer 	= require('timer')
local utils 	= require('utils')
local core   	= require('core')

local camera 	 = require('vision/media/camera')
local hls_reader = require('vision/hls/reader')

local TAG = 'Mock'

local exports = {}

--[[
当前模块用于模拟 lmedia 底层库，实现视频采集，编码，音频输入输出等功能。

]]

-------------------------------------------------------------------------------
-- VideoBuffer

local VideoBuffer = core.Object:extend()
exports.VideoBuffer = VideoBuffer

function VideoBuffer:initialize(sample)
	self._sample = sample or {}
end

function VideoBuffer:length()
	return #(self._sample.sampleData)
end

function VideoBuffer:time_seconds()
	return math.floor(self._sample.sampleTime / 1000)
end

function VideoBuffer:time_useconds()
	return (self._sample.sampleTime % 1000) * 1000
end

function VideoBuffer:to_string()
	return self._sample.sampleData
end

-------------------------------------------------------------------------------
-- VideoEncoder

local VideoEncoder = core.Object:extend()
exports.VideoEncoder = VideoEncoder


--[[
返回一个模拟媒体流
@param id
@param options
@param callback
]]
function VideoEncoder:initialize(channel, options)
	if (type(options) ~= 'table') then
		options = {}
	end

	self.currentSampleId 	= 0
	self.isStopped 			= false
	self.options 			= options
	self.samples 			= {}
	self.startTime 			= 0
	self.startSampleTime	= 0

	-- base path
	if (not options.basePath) then
		options.basePath = path.join(process.cwd(), "")
		print(TAG, 'Base path:', options.basePath)
	end

	-- console.log('VideoEncoder', options)

	if (options.type == 1) then
		self:_load_image_from_file(options)

	else
		self:_load_video_from_file(options)
	end

	return self
end

function VideoEncoder:close()
	print(TAG, 'close')

	self.currentSampleId 	= 0
	self.isStopped 			= true
	self.samples 			= {}
	self.startSampleTime	= 0
	self.startTime 			= 0
	return 0
end

function VideoEncoder:get_fd()
	return -1
end

function VideoEncoder:get_packet_count()
	if (self.isStopped ~= true) then
		return 1
	end

	return 0
end

function VideoEncoder:get_stream()
	if (self.isStopped) then
		print('get_stream', 'isStopped')
		return -1
	end

	local sample = self:_read_next_sample()
	if (not sample) then
		print('get_stream', 'Empty sample')
		self:close()
		return -1
	end

	local sampleData = VideoBuffer:new(sample)	
	return 1, sampleData
end

function VideoEncoder:_load_image_from_file(options)
	--local fileName = options.filename or path.join(options.basePath, '641.ts')
	local filename = path.join(options.basePath, 'examples/test.jpg')
	print('_load_image_from_file', filename)
	fs.readFile(filename, function(ret, data)
		if (not data) then
			return
		end

		self.imageData = data
	end)
end

function VideoEncoder:_load_video_from_file(options)
	local baseTime = 0
	local lastPacketTime  = 0
	local startPacketTime = 0

	if (not options) then
		options = {}
	end

	local function _onStreamStart()

	end

	--[[
	@param packet
	@param sampleTime 1 / 1,000,000 S
	@param sync is sync point
	]]
	local function _onStreamPacket(packetData, packetTime, syncPoint, sps, pps)
		-- pts offset
		if (startPacketTime == 0) then
			startPacketTime = packetTime
		end

		local pts = packetTime - startPacketTime
		--console.log('_onStreamPacket', #packetData, pts, sync);

		-- fix sampleTime
		local sampleTime = baseTime + pts
		if (sampleTime < lastPacketTime) then
			baseTime = lastPacketTime
			sampleTime = baseTime + pts
		end
		lastPacketTime = sampleTime

		-- sample
		local sample = {}
		sample.pps 			= pps
		sample.rawTime 		= sampleTime
		sample.sampleData 	= packetData
		sample.sampleTime 	= sampleTime
		sample.sps 			= sps
		sample.syncPoint  	= syncPoint

		--console.log('_onStreamPacket', syncPoint, sampleTime, #packetData);

		-- append
		local samples = self.samples;
		table.insert(samples, sample)
	end

	local function _onStreamEnd()
		--console.log('stream end', #mockStream.samples);
		local samples = self.samples

		local totalSamples		= #samples
		if (totalSamples < 2) then
			return
		end

		local startSample 		= samples[1]
		local startSampleTime 	= startSample.sampleTime
		local lastSample 		= samples[totalSamples]
		local lastSampleTime 	= lastSample.sampleTime
		
		local avgDuration 		= (lastSampleTime - startSampleTime) / (totalSamples - 1)
		local totalDuration 	= avgDuration * totalSamples

		--console.log('avgDuration', avgDuration)
		--console.log('totalDuration', totalDuration)

		self.avgDuration		= avgDuration
		self.startSampleTime 	= startSampleTime
		self.startTime 			= 0
		self.totalDuration 		= totalDuration

		print(TAG, "Stream:", "duration=" .. math.floor(totalDuration / 1000) 
			.. '/' .. math.floor(avgDuration / 1000)
			.. "ms, total=" .. totalSamples .. "frames")
	end

	-- open file
	local fileName = options.filename or path.join(options.basePath, '641.ts')
	local fileId = fs.openSync(fileName, 'r', 438)
	if (not fileId) then
		print(TAG, 'Invalid media file: ' .. fileName)
		return
	end

	-- init reader
	local reader = hls_reader.StreamReader:new()
	reader:on('end',	_onStreamEnd)
	reader:on('packet', _onStreamPacket)
	reader:on('start', 	_onStreamStart)
	reader:start()
	
	-- read and parse
	local TS_PACKET_SIZE = hls_reader.TS_PACKET_SIZE;
	while true do
		local packet = fs.readSync(fileId, TS_PACKET_SIZE)
		if (not packet) then
			break

		elseif (reader:processPacket(packet) < 0) then
			break
		end
	end

	-- release all
	reader:close()
	fs.closeSync(fileId)
	fileId = -1
end

--[[
加载下一个 Sample
]]
function VideoEncoder:_read_next_sample()
	self.currentSampleId = self.currentSampleId + 1

	local sample
	if (self.imageData) then
		sample =  {}
		sample.sampleData = self.imageData

	else
		sample = self:_read_sample(self.currentSampleId)

	end

	if (sample) then
		if (self.startTime <= 0) then
			self.startTime = process.now()
		end

		sample.sampleTime = (process.now() - self.startTime) -- * 1000
	end

	-- print('_read_next_sample', sample.sampleTime)
	-- print('_read_next_sample', self.currentSampleId)
	return sample
end

--[[
返回指定 ID 的 Sample
@param sampleId Sample ID, 从 1 开始, 以 1 递增
]]
function VideoEncoder:_read_sample(sampleId)
	local samples = self.samples
	if (not samples) then
		return nil
	end

	local totalSamples = #samples
	if (totalSamples < 1) then
		return nil
	end

	local position  = (sampleId - 1) % totalSamples + 1
	local level 	= math.floor((sampleId - 1) / totalSamples)
	local baseTime 	= level * self.totalDuration

	local sample = samples[position]
	local sampleTime 	= baseTime + (sample.rawTime - self.startSampleTime) + 0.5

	sample.level 		= level
	sample.sampleId 	= sampleId
	sample.sampleTime 	= math.floor(sampleTime)

	return sample
end

function VideoEncoder:bind(channel)
	-- Do nothing
	return 0
end

function VideoEncoder:start()
	if (self.isStopped ~= false) then
		self.isStopped = false
	end

	return 0
end

function VideoEncoder:stop()
	if (self.isStopped ~= true) then
		self.isStopped = true
	end

	return 0
end

-------------------------------------------------------------------------------

local VideoInput = core.Object:extend()
exports.VideoInput = VideoInput

-------------------------------------------------------------------------------

function exports.init()
	return 0
end

function exports.video_encoder_open(channel, options) 
	--console.log(TAG, 'video_encoder', channel, options) 
	if (options.type == 1) then
		if (not exports.imageEncoder) then
			exports.imageEncoder = VideoEncoder:new(channel, options)
		end

		return exports.imageEncoder

	else
		if (not exports.videoEncoder) then
			exports.videoEncoder = VideoEncoder:new(channel, options)
		end

		return exports.videoEncoder
	end
end

function exports.video_in_init(channelCount)
	return 0
end

function exports.video_in_open(videoId, resolution)
	return VideoInput:new(videoId, resolution)
end

function exports.video_in_release()
	return 0
end

function exports.release()
	return 0
end

function exports.version()
	return "mock"
end

function exports.snapshot(options, callback)
	options = options or {}
	if (not options.basePath) then
		print(options.basePath)
	end

	local filename = path.join(options.basePath, 'examples/test.jpg')
	print('mock image: ', filename)

	fs.readFile(filename, function(ret, data)
		if (not data) then
			if (callback) then
				callback(nil, ret)
			end
			return
		end

		--console.log('snapshot', ret, #data)

		if (callback) then
			callback(data, {mimetype='image/jpg'})
		end
	end)

	return 0
end

return exports
