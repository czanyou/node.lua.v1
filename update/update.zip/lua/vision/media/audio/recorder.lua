local core  = require('core')
local utils = require('utils')

local exports = {}

-------------------------------------------------------------------------------
-- AudioRecorder
-- AudioRecorder provides access to volume and ringer mode control.

local AudioRecorder = core.Emitter:extend()
exports.AudioRecorder = AudioRecorder

function AudioRecorder:initialize(cameraId, options)


end


return exports