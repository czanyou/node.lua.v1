local core  = require('core')
local utils = require('utils')

local exports = {}

-------------------------------------------------------------------------------
-- AudioManager
-- AudioManager provides access to volume and ringer mode control.

local AudioManager = core.Emitter:extend()
exports.AudioManager = AudioManager

function AudioManager:initialize(cameraId, options)


end


return exports

