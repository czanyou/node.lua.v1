local core  = require('core')
local utils = require('utils')

local exports = {}

-------------------------------------------------------------------------------
-- AudioPlayer
-- AudioPlayer provides access to volume and ringer mode control.

local AudioPlayer = core.Emitter:extend()
exports.AudioPlayer = AudioPlayer

function AudioPlayer:initialize(cameraId, options)


end


return exports