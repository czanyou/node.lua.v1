--[[

Copyright 2016 The Node.lua Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS-IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

--]]
local utils = require('utils')
local core  = require('core')

local exports = { }

-------------------------------------------------------------------------------
-- PlayList 用来读写 M3U8 的类
-- @event error 
-- @event item 在添加一个新的 segment 时调用
-- @event remove 在删除一个最老的 segment 时调用(仅限于实时流)

local PlayList = core.Emitter:extend()
exports.PlayList = PlayList

function PlayList:initialize()
    self.isEndList      = false
    self.maxSegment     = 3
    self.playItems      = {}
    self.properties     = {}
    self.streamItems    = {}
end

-- 添加一个分片
-- @param path {String}
-- @param duration {Number}
function PlayList:addItem(path, duration)
    if (not duration) or (not path) then
        return self
    end

    local item = { duration = duration, path = path }
    table.insert(self.playItems, item)

    if (not self.isEndList) then
        while (#self.playItems > self.maxSegment) do
            self:removeItem(1)
        end
    end

    self:setTargetDuration(self:getMaxDuration())

    self:emit('item', item)
    return self
end

function PlayList:get(key)
    return self.properties[key]
end

-- 返回第一个分片的序列号
function PlayList:getMediaSequence()
    return self:get('EXT-X-MEDIA-SEQUENCE')
end

-- 返回当前列表中最长的分片的长度
function PlayList:getMaxDuration()
    local maxDuration = 3.0
    for k, v in ipairs(self.playItems) do
        if (maxDuration < v.duration) then
            maxDuration = v.duration
        end
    end

    return math.floor(maxDuration + 0.5)
end

function PlayList:init()
    -- #EXTM3U
    -- #EXT-X-VERSION: 3
    -- #EXT-X-TARGETDURATION: 8
    -- #EXT-X-MEDIA-SEQUENCE: 2680

    local headers = self.properties
    headers['EXT-X-VERSION']        = 3
    headers['EXT-X-TARGETDURATION'] = 10    -- 每个分片TS的最大的时长
    headers['EXT-X-MEDIA-SEQUENCE'] = 1     -- 第一个TS分片的序列号 
end

-- 解析指定的列表
function PlayList:parse(listData)
    if (not listData) then
        return
    end

    local lines = listData:split('\n')

    local playItem = nil
    local streamItem = nil

    for key,line in pairs(lines) do
    	-- console.log(key, line, #line, line:byte(1))

    	if (#line <= 0) then

    	elseif (line:byte(1) == 35) then -- 35: '#'
    		if (line == '#EXTM3U') then
                -- start

    		elseif (line == '#EXT-X-ENDLIST') then
                -- end
                self.isEndList = true
    			break;
    		end

    		local a, offset, tag, value = line:find("^#([^:]+):%s*([^\r\n]+)", 1)
    		--console.log(a, offset, tag, value)

    		if (tag and value) then
    			if (tag == 'EXTINF') then
                    local tokens = value:split(',')
    				playItem = {}
    				playItem.duration = tokens[1] or 0
    				table.insert(self.playItems, playItem)

                elseif (tag == 'EXT-X-STREAM-INF') then
                    streamItem = {}
                    streamItem.attributes = self:parseAttributes(value)
                    table.insert(self.streamItems, streamItem)

                elseif (playItem) then
                    playItem[tag] = self:parseAttributes(value)

                elseif (streamItem) then
                    streamItem[tag] = self:parseAttributes(value)

    			else
    				self.properties[tag] = value
    			end
    		end

        elseif (streamItem) then
            if (not streamItem.path) then
                streamItem.path = line:trim()
            end

    	elseif (playItem) then
    		if (not playItem.path) then
    			playItem.path = line:trim()
    		end
    	end

    end

    return self
end

function PlayList:parseAttributes(value)
    local tokens = value:split(",")

    return tokens
end

-- 从列表头部删除一个分片
function PlayList:removeItem(index)
    index = index or 1
    if (#self.playItems > 0) then
        local ret = table.remove(self.playItems, index)
        self:setMediaSequence(self:getMediaSequence() + 1)

        self:emit('remove', ret)
    end
end

function PlayList:set(key, value)
    if (key) then
        self.properties[key] = value
    end
end

-- 设置是否有 END 标记, 否表示是实时流
function PlayList:setEndList(isEndList)
    self.isEndList = not not isEndList
end

-- 设置第一个分片的序列号
function PlayList:setMediaSequence(sequence)
    self:set('EXT-X-MEDIA-SEQUENCE', sequence)
end

function PlayList:setTargetDuration(duration)
    self:set('EXT-X-TARGETDURATION', duration)
end

function PlayList:toString()
    local endLine = '\r\n'
    local buffer = utils.StringBuffer:new()
    buffer:append('#EXTM3U'):append(endLine) -- m3u文件头，必须放在第一行

    -- headers
    for k, v in pairs(self.properties) do
        if (not tonumber(k)) then
            buffer:append('#'):append(k):append(':'):append(v):append(endLine)
        end
    end

    buffer:append(endLine)

    -- items
    -- extra info，分片TS的信息，如时长，带宽等
    for k,item in ipairs(self.playItems) do
        buffer:append('#EXTINF:'):append(item.duration):append(','):append(endLine)
        buffer:append(item.path):append(endLine)
    end

    -- end
    -- #EXT-X-ALLOW-CACHE          是否允许cache
    -- #EXT-X-ENDLIST              m3u8文件结束符
    if (self.isEndList) then
        buffer:append('#EXT-X-ENDLIST'):append(endLine)
    end

    buffer:append(endLine)
    return buffer:toString()
end

-------------------------------------------------------------------------------
-- exports

function exports.newList(...)
    local playList = PlayList:new()
	playList:init()
    return playList
end

function exports.parse(...)
    local playList = PlayList:new()
	local ret = playList:parse(...)
    return playList, ret
end

return exports
