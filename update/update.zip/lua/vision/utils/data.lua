local utils 	= require('utils')
local thread 	= require('thread')
local sqlite 	= require('vision/utils/sqlite3')
local path 		= require('path')
local json 		= require('json')

local DATA_TABLE 	= 'data'
local DATABASE_NAME = 'data.db'

local isInited = false
local data_stream_last

local exports = {}

local function paddingZero(value)
	if (value < 10) then
		return '0' .. value
	else
		return value
	end
end

local function data_stream_open(name)
	local dirname  = exports.dirname or utils.dirname()
	local filename = path.join(dirname, name or DATABASE_NAME)

	local db = sqlite.open(filename)
	if (not db) then
		print('data_stream_open', 'open database failed', filename)
		return
	end

	print(filename)

	return db
end

-------------------------------------------------------------------------------
-- add

local function data_stream_add(db, stream, value, time, inteval) 
	-- check count
	if (time) then
		local sql = "SELECT COUNT(id) AS id FROM data WHERE stream=? AND timestamp=?"
		local stmt, err = db:prepare(sql)
		assert(stmt, err)

		stmt:bind(stream, time)

		local count = stmt:first_cols() or 0
		stmt:close()

		if (count > 0) then
			return
		end
	end

	local timestamp = time or os.time()
	if (inteval) then
		local ret = data_stream_last(db, stream)
		if (ret and ret.timestamp) then
			local span = math.abs(timestamp - ret.timestamp)
			if (span < inteval) then
				--print('inteval', span, inteval)
				return
			end
		end
	end

	-- max id
	local sql = "SELECT MAX(id) AS id FROM data"
	local stmt, err = db:prepare(sql)
	assert(stmt, err)

	local id = (stmt:first_cols() or 0) + 1
	stmt:close()

	-- insert
	local sql = "INSERT INTO data(id, stream, value, timestamp) VALUES (?, ?, ?, ?)"
	local stmt, err = db:prepare(sql)
	assert(stmt, err)

	stmt:bind(id, stream, value, timestamp)
	stmt:exec()
	stmt:close()
end

-------------------------------------------------------------------------------
-- list all

local function data_stream_clear(db)
	local sql = "SELECT * FROM data WHERE stream='temperature' AND value>?"
	local stmt = db:prepare(sql)
	if (not stmt) then
		return
	end

	stmt:bind(value or 40 * 100)

	for row in stmt:rows() do
		console.log(row)
	end

	stmt:close()

	db:exec("DELETE FROM data WHERE stream='temperature' AND value > 40 * 100")
end


local function data_stream_exists(db, name)
	local sql = "SELECT COUNT(*) AS c FROM sqlite_master WHERE type='table' AND name=?"
	local stmt = db:prepare(sql)
	local count = 0
	if (stmt) then
		stmt:bind(name)
		count = stmt:first_cols() or 0

		print('count', count)
		stmt:close()
	end

	if (count > 0) then
		return true
	end
end


local function data_stream_find_range(db, stream, startTime, endTime)
	endTime = endTime or os.time()

	local result = {}

	for i = 1, #stream do
		local type = stream[i]
		local tokens = type:split('.')
		local method = tokens[2] or 'avg'

		local cols = 'COUNT(*) as count, ' .. method .. '(value) as value'

		local sql = "SELECT " .. cols .. " FROM data "
			.. "WHERE stream=? AND timestamp>=? AND timestamp<? ORDER BY timestamp ASC"
		local stmt, err = db:prepare(sql)
		assert(stmt, err)

		stmt:bind(tokens[1], startTime, endTime)

		local row = stmt:first_row()
		--console.log(sql, type, row)

		if (row.value) then
			result.count = row.count
			result[type] = row.value
		end
	end

	return result
end

local function data_stream_find_by_day(db, stream, offset)
	local count = 24

	local date = os.date('*t')
	date.hour  = 0
	date.min   = 0
	date.sec   = 0

	offset = tonumber(offset)
	if (offset) then
		date.day = date.day + offset
	end

	local startTime = os.time(date)

	local list = {}
	for i = 1, count do

		date.hour = date.hour + 1
		local endTime = os.time(date)

		local ret = data_stream_find_range(db, stream, startTime, endTime) or {}
		ret.startTime = startTime
		table.insert(list, ret)

		startTime = endTime
	end

	return list
end

local function data_stream_find_by_year(db, stream, offset)
	local count = 12

	local date = os.date('*t')
	date.day  = 1
	date.hour = 0
	date.min  = 0
	date.sec  = 0
	date.month  = date.month - count + 1

	offset = tonumber(offset)
	if (offset) then
		date.year = date.year + offset
	end

	local startTime = os.time(date)

	local list = {}
	for i = 1, count do
		date.month = date.month + 1
		local endTime = os.time(date)

		local ret = data_stream_find_range(db, stream, startTime, endTime) or {}
		ret.startTime = startTime
		table.insert(list, ret)

		startTime = endTime
	end

	return list
end

local function data_stream_find_by_month(db, stream, offset)
	local count = 31

	local date = os.date('*t')
	date.day  = date.day - count + 1
	date.hour = 0
	date.min  = 0
	date.sec  = 0

	offset = tonumber(offset)
	if (offset) then
		date.month = date.month + offset
	end

	local startTime = os.time(date)

	local list = {}
	for i = 1, count do
		date.day = date.day + 1
		local endTime = os.time(date)

		local ret = data_stream_find_range(db, stream, startTime, endTime) or {}
		ret.startTime = startTime
		table.insert(list, ret)

		startTime = endTime
	end

	return list
end

local function data_stream_find_by_week(db, stream, offset)
	local count = 7
	
	-- date
	local date = os.date('*t')
	date.day  = date.day - count + 1
	date.hour = 0
	date.min  = 0
	date.sec  = 0

	offset = tonumber(offset)
	if (offset) then
		date.day = date.day + offset * 7
	end

	local startTime = os.time(date)

	-- query
	local list = {}
	for i = 1, count do

		date.day = date.day + 1
		local endTime = os.time(date)

		local ret = data_stream_find_range(db, stream, startTime, endTime) or {}
		ret.startTime = startTime
		table.insert(list, ret)

		startTime = endTime
	end

	return list
end

local function data_stream_find(db, stream, mode, offset)
	mode   = mode or 'day'
	offset = offset or 0

	print('data_stream_find', 'mode', mode, 'offset', offset)

	if (mode == 'day') then
		return data_stream_find_by_day(db, stream, offset)

	elseif (mode == 'year') then
		return data_stream_find_by_year(db, stream, offset)

	elseif (mode == 'week') then
		return data_stream_find_by_week(db, stream, offset)

	elseif (mode == 'month') then
		return data_stream_find_by_month(db, stream, offset)
	end
end

local function data_stream_import(db, stream)
	local db_old = data_stream_open('www/data.db')

	local sql = "SELECT * FROM sht20"

	local stmt, err = db_old:prepare(sql)
	assert(stmt, err)

	local index = 0
	local lastTime = process.uptime()

	for row in stmt:rows() do
		index = index + 1

		local temperature = row.temperature / 100
		local humidity    = row.humidity / 100
		--console.log(humidity)

		data_stream_add(db, 'temperature', temperature, row.time)
		data_stream_add(db, 'humidity',	   humidity,    row.time)

		--print(index)
		local now = process.uptime()
		if (now - lastTime) > 1 then
			print('index: ' .. index)
			lastTime = now
		end
	end

	stmt:close()
	db_old:close()

	print('total: ' .. index)
end

local function data_stream_init(db)
	if (isInited) then
		return
	end

	isInited = true

	local sql = "CREATE TABLE data (id INT, stream TEXT, value TEXT, seq INT, timestamp INT)"

	if (not data_stream_exists(db, DATA_TABLE)) then
		db:exec(sql)
	end
end

function data_stream_last(db, stream) 
	local sql = "SELECT id, stream, value, timestamp FROM data WHERE stream=? ORDER BY timestamp DESC"
	local stmt, err = db:prepare(sql)
	assert(stmt, err)

	stmt:bind(stream)

	local ret = stmt:first_row()
	stmt:close()
	return ret
end

local function data_stream_list(db, stream, limit)
	if (type(stream) == 'string') then
		stream = { stream }
	end

	limit = limit or 20

	local where = nil
	local sql = "SELECT id,stream,value,timestamp FROM data"

	if (stream and #stream > 0) then
		sql = sql .. ' WHERE (stream=?'
		for i = 2, #stream do
			sql = sql .. ' OR stream=?'
		end

		sql = sql .. ' )'
	end
	
	local stmt, err = db:prepare(sql)
	assert(stmt, err)

	if (stream) then
		console.log(sql, stream)
		stmt:bind(table.unpack(stream))
	end

	local ret = {}

	local index = 0
	for row in stmt:rows() do
		table.insert(ret, row)

		index = index + 1
		if (index > limit) then
			break
		end
	end

	stmt:close()

	return ret
end


-------------------------------------------------------------------------------
-- exports

-- Add a data point
-- @param stream {String} data stream type
-- @param value {Any} data point value
function exports.add(db, stream, value, inteval)
	return data_stream_add(db, stream, value, nil, inteval)
end


function exports.clear(db, ...)
	return data_stream_clear(db, ...)
end

function exports.close(db)
	if (db) then db:close() end
end

-- @param stream {Array} data stream type
-- @param mode {String} query type
-- @param offset {Number} 
function exports.find(db, stream, mode, offset)
	return data_stream_find(db, stream, mode, offset)
end

function exports.import(db)
	data_stream_import(db)
end

function exports.init(db)
	data_stream_init(db)
end

function exports.last(db, stream)
	return data_stream_last(db, stream)
end

function exports.list(db, stream)
	return data_stream_list(db, stream)
end

function exports.open(name, mode)
	local db = data_stream_open(name, mode)
	db.import 	= exports.import
	db.last 	= exports.last
	db.list	 	= exports.list
	db.import 	= exports.import
	db.import 	= exports.import
	db.import 	= exports.import

	return db
end

function exports.query(stream, mode, offset, options)
	local db = exports.open()
	if (not db) then 
		return
	end

    options = options or {}
    mode    = mode or 'month'
    offset  = offset or 0

    local data1  = {}
    local data2  = {}
    local data3  = {}
    local labels = {}
    local series = {}

    local chartData = { title = stream, labels = labels, series = series}

    local streams = {}

    if (options.max) then
        table.insert(series,  { name = "max",  data = data1 })
        table.insert(streams, stream .. '.max')
    end

    if (options.min) then
        table.insert(series,  { name = "min",  data = data2 })
        table.insert(streams, stream .. '.min')
    end

    if (#streams <= 0) then
    	options.avg = true
    end

    if (options.avg) then
        table.insert(series,  { name = "avg",  data = data3 })
        table.insert(streams, stream)
    end

    local ret = exports.find(db, streams, mode, offset) or {}
    local count = #ret
    for i = 1, count do
        local item = ret[i]

        -- value
   		if (options.max) then
        	table.insert(data1, item[stream .. '.max'] or json.null)
        end

        if (options.min) then
        	table.insert(data2, item[stream .. '.min'] or json.null)
        end

        if (options.avg) then
            table.insert(data3, item[stream] or json.null)
        end

        -- label
        local date = os.date("*t", item.startTime)
        local label = ""
        if (mode == 'day') then
            label = paddingZero(date.hour) .. ":00"

        elseif (mode == 'year') then
            label = date.year .. '-' .. paddingZero(date.month)

        else
            label = paddingZero(date.month) .. '-' .. paddingZero(date.day)
        end
        table.insert(labels, label)
    end

	db:close()
    return { ret = 0, data = chartData }
end

return exports
