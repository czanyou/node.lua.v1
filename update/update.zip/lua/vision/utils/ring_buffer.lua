--[[

Copyright 2016 The Node.lua Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS-IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

--]]
local core 	 = require('core')
local utils  = require('utils')
local url 	 = require('url')
local buffer = require('buffer')

local exports = { }

local RingBuffer = core.Emitter:extend()
exports.RingBuffer = RingBuffer

function RingBuffer:initialize(size, length)
	self.maxSize   = size
	self.maxLength = length
	self.head   = 0
	self.tail   = 0

	self.buffer = buffer.Buffer:new(self.maxSize)
	self.queue  = {}
end

function RingBuffer:push(data, meta)
	if (self:size() >= self.maxLength - 1) then
		return
	end

	local item = {}
	item.meta = meta
	item.offset = 1
	item.size = #data

	local pos = (self.head % self.maxLength) + 1
	self.head = self.head + 1

	self.queue[pos] = item
end

function RingBuffer:_free(item)
	if (not item) then
		return
	end


end

function RingBuffer:peek()
	if (self.tail >= self.head) then
		return
	end

	local pos = (self.tail % self.maxLength) + 1
	return self.queue[pos]
end

function RingBuffer:pop()
	if (self.tail >= self.head) then
		return
	end

	local pos = (self.tail % self.maxLength) + 1
	local ret = self.queue[pos]
	self.queue[pos] = nil
	self.tail = self.tail + 1

	self:_free(item)
	return ret
end

function RingBuffer:size()
	return self.head - self.tail
end

function RingBuffer:clear()
	while (self.tail < self.head) do
		self:pop()
	end
end

return exports
