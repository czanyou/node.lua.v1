--[[

Copyright 2016 The Node.lua Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS-IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

--]]

local path 	 = require('path')
local utils  = require('utils')
local lmedia = require('lmedia')
local core 	 = require('core')
local fs 	 = require('fs')

local exports = {}

local Watchdog = core.Emitter:extend()
exports.Watchdog = Watchdog

function Watchdog:initialize()
	self.watchdog = -1

end

--[[
 * 关闭看门狗设备. 
 * @param flags 当 flags 1 时表示让系统收回 watchdog 监视权, 默认为 0.
--]] 
function Watchdog:close(flags)
	if (self.watchdog <= 0) then
		return
	end

	if (flags) then
		fs.writeSync(self.watchdog, 'V');
	end

	fs.closeSync(self.watchdog)
	self.watchdog = -1
end

function Watchdog:feed()
	if (self.watchdog <= 0) then
		return false
	end

	fs.writeSync(self.watchdog, '\0');

	return true
end

-- 打开并启用看门狗设备. 
function Watchdog:open(timeout)
	if (self.watchdog > 0) then
		return
	end

	local deviceName = "/dev/watchdog"
	self.watchdog = fs.openSync(deviceName)

	if (timeout and timeout > 0) then
		self:timeout(timeout)
		self:enable(true)
	end
end

-- 指出看门狗是否已经启用. 如果没有打开设备将返回 FALSE.
function Watchdog:enable(enable)

end

-- 返回看门狗的超时时间
function Watchdog:timeout(timeout)

end

return exports
