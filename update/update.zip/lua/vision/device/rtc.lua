local path 	 = require('path')
local utils  = require('utils')
local lmedia = require('lmedia')
local core 	 = require('core')
local fs 	 = require('fs')

local exports = {}

local RTC = core.Emitter:extend()
exports.RTC = RTC

function RTC:initialize()

end


return exports
