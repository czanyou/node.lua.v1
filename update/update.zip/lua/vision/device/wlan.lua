local path 	 = require('path')
local utils  = require('utils')
local lmedia = require('lmedia')
local core 	 = require('core')
local fs 	 = require('fs')

local exports = {}

local Wlan = core.Emitter:extend()
exports.Wlan = Wlan

function Wlan:initialize()
	self.wlan = -1

end


return exports
