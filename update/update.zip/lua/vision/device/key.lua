local path 	 = require('path')
local utils  = require('utils')
local lmedia = require('lmedia')
local core 	 = require('core')
local fs 	 = require('fs')

local exports = {}

local Key = core.Emitter:extend()
exports.Key = Key

function Key:initialize()
	self.led = -1

end

function Key:get()
	
end

function Key:set()
	
end

return exports