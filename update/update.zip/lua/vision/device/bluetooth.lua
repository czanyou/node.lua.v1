--[[

Copyright 2016 The Node.lua Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS-IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

--]]
local ble 		= require('lbluetooth')
local fs  		= require('fs')
local uv 	    = require('uv')

local exports = {}

local ble_poll = nil

local function start_le_scan()
    if (ble_poll) then
        return
    end

    -- process ble adv data
    local onData = function(err, data)
        local callback = exports.callback
        if (callback) then
            callback(err, data)
        end
    end

    -- open ble device
	ble.reset()
	local deviceHandler = ble.open()
    if (deviceHandler < 0) then
        onData('Could not open device')
        return -1
    end

    -- start scan
    local ret = ble.scan()
    if (ret < 0) then
        ble.close()
        onData('Could not start scan')
        return -1
    end

	-- print("ble fd = " .. deviceHandler)

    local onRead = function()
        if (deviceHandler) then
            fs.read(deviceHandler, onData)
        end
    end
	
    -- use poll to monitor ble device
    local poll = uv.new_poll(deviceHandler)
	poll:start('r', onRead)

    ble_poll = poll
end

-- 开始扫描
function exports.startScan(options, callback)
    -- function(callback)
    if (type(options) == 'function') then
        callback = options; options = nil
    end

    options = options or {}
    exports.callback = callback

    if (not ble_poll) then
        start_le_scan(options)
    end
end

-- 停止扫描, 并关闭相关的蓝牙设备 
function exports.stopScan()
    if (ble_poll) then
        ble_poll:stop()
        ble_poll = nil
    end

    ble.close()
end

return exports
