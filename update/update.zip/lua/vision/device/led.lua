local path 	 = require('path')
local utils  = require('utils')
local lmedia = require('lmedia')
local core 	 = require('core')
local fs 	 = require('fs')

local exports = {}

local Led = core.Emitter:extend()
exports.Led = Led

function Led:initialize()
	self.led = -1

end

function Led:on()
	
end

function Led:off()
	
end

return exports
