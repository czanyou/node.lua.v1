--[[

Copyright 2016 The Node.lua Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS-IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

--]]

local core   	= require('core')
local fs     	= require('fs')
local json   	= require('json')
local path   	= require('path')
local utils  	= require('utils')

local conf    	= require('ext/conf')
local package 	= require('ext/package')
local upgrade 	= require('ext/upgrade')
local app 		= require('app')

-------------------------------------------------------------------------------
-- meta

local meta = { }
meta.name        = "lpm"
meta.version     = "3.0.1"
meta.description = "Lua package manager (Node.lua command-line tool)."
meta.tags        = { "lpm", "package", "command-line" }

-------------------------------------------------------------------------------
-- exports

local exports = { meta = meta }

exports.rootPath = app.rootPath
exports.rootURL  = app.rootURL

-------------------------------------------------------------------------------
-- config

local config = {}

-- split "name:key" string
local function parseName(name) 
	local pos = name:find(':')
	if (pos) then
		return name:sub(1, pos - 1), name:sub(pos + 1)
	else
		return 'user', name
	end
end

function config.commit(name)

end

-- 删除指定名称的配置参数项的值
function config.del(name)
	if (not name) then
		print('Not enough arguments provided')
		print('Usage: lpm config del <key>')
		return
	end

	local file, key = parseName(name)

	local profile = conf(file or 'user')
	if (profile:get(key)) then
		profile:set(key, nil)
		profile:commit()
	end

	print('del `' .. tostring(name) .. '`')
end

-- 打印指定名称的配置参数项的值
function config.get(name)
	if (not name) then
		print('Not enough arguments provided')
		print('Usage: lpm get <key>')
		return
	end

	local file, key = parseName(name)

	local profile = conf(file or 'user')
	console.log(profile:get(key))
end

function config.help()
	local text = [[

Manage the lpm configuration files

Usage: 
  lpm config del <key>         - Deletes the key from configuration files.
  lpm config get <key>         - Echo the config value to stdout.
  lpm config list              - Show all config files
  lpm config list <name>       - Show all the config settings.
  lpm config set <key> <value> - Sets the config key to the value.
  lpm get <key>                - Echo the config value to stdout.
  lpm set <key> <value>        - Sets the config key to the value.

key: "[filename:][root.]<name>", ex: "network:lan.mode"

Aliases: c, conf

]]

	print(text)
end

function config.list(name)
	if (not name) then
		local confPath = path.join(app.rootPath, 'conf')
		local files = fs.readdirSync(confPath)
		print(confPath .. ':')
		print(table.unpack(files))
		return
	end

	local profile = conf(name or 'user')

	print(profile.filename .. ': ')
	console.log(profile.settings)
end

-- 设置指定名称的配置参数项的值
function config.set(name, value)
	if (not name) or (not value) then
		print('Not enough arguments provided')
		print('Usage: lpm set <key> <value>')
		return
	end

	local file, key = parseName(name)

	local profile = conf(file or 'user')
	local oldValue = profile:get(key)
	if (not oldValue) or (value ~= oldValue) then
		profile:set(key, value)
		profile:commit()
	end

	print('set `' .. tostring(name) .. '` = `' .. tostring(value) .. '`')
end

function exports.config(action, ...)
	local method = config[action or 'help']
	if (method) then
		return method(...)

	else
		config.help()
	end
end

exports.del  = config.del
exports.get  = config.get
exports.set  = config.set
exports.c    = exports.config
exports.conf = exports.config

-------------------------------------------------------------------------------
-- application

local _executeApplication = function (name, action, ...)
	--print(name, action, ...)

	local manager = app.manager()
	local ret, err = manager:execute(name, action, ...)
	if (not ret) or (ret < 0) then
		exports.usage()
		print("")
		print("Unknown command: " .. tostring(name))
	end
end

local _sendMessage = function (method, params, callback)
	if (not method) then
		return
	end

	local rpc      = require('ext/rpc')
	local IPC_PORT = 53210
	rpc.call(IPC_PORT, method, params, function(err, result)
		if (err) then
			console.log(err) 
		else
			console.log(result)
		end
	end)
end

-- Display lpm bin path
function exports.bin()
	print(path.join(exports.rootPath, 'bin'))
end

-- -- Start a application with daemon mode
function exports.daemon(name, ...)
	if (not name) then
		_executeApplication('lhost', 'help')
		return
	end
	
	_executeApplication('lhost', 'enable', name, ...)

	local manager = app.manager()
	manager:daemon(name)
end

-- Kill the application process
function exports.kill(name, ...)
	if (not name) then
		_executeApplication('lhost', 'help')
		return
	end

	_executeApplication('lhost', 'kill', name, ...)
end

-- Display the installed applications
function exports.list(name)
	local manager = app.manager()
	manager:list(name)
end

-- Display the running application
function exports.ps(...)
	_executeApplication('lhost', 'list', ...)
end

-- Restart the application
function exports.restart(name, ...)
	if (not name) then
		_executeApplication('lhost', 'help')
		return
	end

	_executeApplication('lhost', 'restart', name, ...)
end

-- Display lpm root path
function exports.root()
	print(exports.rootPath)
end

-- Start a application
function exports.start(name, ...)
	if (not name) then
		_executeApplication('lhost', 'help')
		return
	end

	_executeApplication('lhost', 'enable', name, ...)

	local manager = app.manager()
	manager:daemon(name)

	--_executeApplication(name, 'start', ...)
end

-- Stop the application
function exports.stop(name, ...)
	if (not name) then
		_executeApplication('lhost', 'help')
		return
	end

	_executeApplication('lhost', 'stop', name, ...)
end

-------------------------------------------------------------------------------
-- package & upgrade

function exports.check(...)
	upgrade.check(...)
end

function exports.clean(...)
	package.clean(...)
end

function exports.colors(...)
	console.colors(...)
end

function exports.connect(...)
	upgrade.connect(...)
end

function exports.deploy(...)
	upgrade.deploy(...)
end

function exports.disconnect(...)
	upgrade.disconnect(...)
end

-- Install new packages
function exports.install(...)
	package.pack()
	upgrade.install(...)
end

function exports.pack(...)
	package.pack(...)
end

function exports.publish(...)
	package.publish(...)
end

-- Remove packages
function exports.remove(...)
	upgrade.remove(...)
end

-- Retrieve new lists of packages
function exports.update(...)
	package.update(...)
end

-- Perform an upgrade
function exports.upgrade(...)
	upgrade.upgrade(...)
end

-------------------------------------------------------------------------------
-- misc

-- Login to the cloud platform
function exports.login(...)
	_executeApplication('sdcp', 'login', ...)
end

-- Logout from the cloud platform
function exports.logout(...)
	_executeApplication('sdcp', 'logout', ...)
end

-- Check the cloud platform
function exports.ping(...)
	_executeApplication('sdcp', 'ping', ...)
end

-- Scanning for nearby devices
function exports.scan(...)
	_executeApplication('sdcp', 'scan', ...)
end

-- Display the version information
function exports.version()
	print("Node.lua v" .. tostring(process.version) .. ' with:')
	for k, v in pairs(process.versions) do
		print(" - " .. k .. " v" .. v)
	end

	local info = require('cjson')
	if (info and info.VERSION) then
		print(" - cjson v" .. info.VERSION)
	end

	local ret, info = pcall(require, 'lmbedtls.md')
	if (info and info._VERSION) then	
		print(" - mbedtls v" .. info.VERSION)
	end

	local ret, info = pcall(require, 'lsqlite')
	if (info and info.VERSION) then	
		print(" - sqlite v" .. info.VERSION)
	end

	local ret, info = pcall(require, 'miniz')
	if (info and info.VERSION) then	
		print(" - miniz v" .. info.VERSION)
	end

	local ret, info = pcall(require, 'lmedia')
	if (info and info.version) then	
		print(" - lmedia v" .. info.version())
	end	

	local ret, info = pcall(require, 'lhttp_parser')
	if (info and info.VERSION_MAJOR) then	
		print(" - http_parser v" .. math.floor(info.VERSION_MAJOR) .. "." .. info.VERSION_MINOR)
	end	

	local filename = path.join(exports.rootPath, 'package.json')
	local packageInfo = json.parse(fs.readFileSync(filename))
	if (not packageInfo) then
		return
	end

	--console.log(packageInfo)
	print(string.format([[

System information:
- target: %s
- version: %s
	]], packageInfo.target, packageInfo.version))
end

function exports.usage()
	local color  = utils.color
	local quotes = color('quotes')
	local sep 	 = color('braces')
	local highlight = color('highlight')
	local normal = color()

	print([[

Usage: lpm <command> [args]
]])

	print(sep .. [[
where <command> is one of:
    config, connect, deploy, get, help, install, kill, list, ps, remove
    restart, root, scan, set, start, stop, update, upgrade
]], normal)

	print([[
   or: lpm <name> <command> [args]
]])
	
	print(sep .. [[
where <name> is the name of the application, located in 
    '$NODE_LUA_ROOT/app/<name>.app', the supported values of <command>
    depend on the invoked application.
]], normal)

	print([[
   or: lpm help   - involved overview
       lpm list   - list all installed applications
	]])

	print('lpm@' .. process.version .. ' ' .. app.rootPath)

end

-- Display the help information
function exports.help()
	local color  = utils.color
	local quotes = color('quotes')
	local sep 	 = color('braces')
	local highlight = color('highlight')
	local normal = color()
	print(string.format([[

lpm - lua package manager.

lpm is the package manager for the Node Lua platform. It is used to 
publish, discover, install, and develop node application programs.

%susage: lpm <command> [args]%s

where <command> is one of:

Developer Usage:

- connect <host>    %sConnect a device%s
- deploy <host>     %sDeploy the last SDK to device%s
- install <name>    %sInstall new application%s
- remove <name>     %sRemove applications%s
- scan <timeout>    %sScan devices%s

Configuration Usage:

- config <args>     %sManager the lpm configuration files%s
- get <key>
- set <key> <value>

Other Usage:

- help              %sGet help on lpm%s
- kill <name>       %sKill a application process%s
- list <name>       %sList all installed applications%s
- ps                %sList all running application processes%s
- restart <name>    %sRestart a application%s
- root              %sDisplay lpm root path%s
- start <name>      %sStart a application as daemon mode%s
- stop <name>       %sStop the application%s
- update [host]     %sRetrieve new lists of applications%s
- upgrade [host]    %sPerform an upgrade%s
- version           %sDisplay version informations%s
]], highlight, normal,  
sep, normal, sep, normal, sep, normal,
sep, normal, sep, normal, sep, normal,
sep, normal, sep, normal, sep, normal,
sep, normal, sep, normal, sep, normal,
sep, normal, sep, normal, sep, normal, 
sep, normal, sep, normal, sep, normal
))

	print('lpm@' .. process.version .. ' ' .. app.rootPath)

--[[

- build             Build Lua source packages
- clean             Clean old downloaded archive files
- info              Print device information
- publish           Publish for source packages
- show <name>       Show package & application information

--]]

end

-------------------------------------------------------------------------------
-- call

function exports.call(args)
	local command = args[1]
	table.remove(args, 1)

	local func = exports[command or 'usage']
	if (type(func) == 'function') then
		local status, ret = pcall(func, table.unpack(args))
		run_loop()

		if (not status) then
			print(ret)
		end

		return ret

	else
		_executeApplication(command, table.unpack(args))
	end
end

setmetatable(exports, {
	__call = function(self, ...) 
		self.call(...)
	end
})

return exports
