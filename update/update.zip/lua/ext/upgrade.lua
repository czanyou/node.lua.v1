--[[

Copyright 2016 The Node.lua Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS-IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

--]]

local core      = require('core')
local fs        = require('fs')
local http      = require('http')
local json      = require('json')
local miniz     = require('miniz')
local path      = require('path')
local thread    = require('thread')
local timer     = require('timer')
local url       = require('url')
local utils     = require('utils')

local request  	= require('ext/request')
local conf   	= require('ext/conf')

--[[
Node.lua 系统更新程序
======

这个脚本用于自动在线更新 Node.lua SDK, 包含可执行主程序, 核心库, 以及核心应用等等

--]]

local exports = {}

local formatFloat, formatBytes, downloadFile, getRootPath, getSystemTarget

local noop = function() end

-- Format the bytes number to human-readable string
function formatBytes(bytes)
	if (bytes < 1024) then
		return bytes .. " Bytes"

	elseif (bytes < 1024 * 1024) then
		return formatFloat(bytes / 1024) .. " KBytes"

	elseif (bytes < 1024 * 1024 * 1024) then
		return formatFloat(bytes / (1024 * 1024)) .. " MBytes"

	elseif (bytes < 1024 * 1024 * 1024 * 1024) then
		return formatFloat(bytes / (1024 * 1024 * 1024)) .. " GBytes"

	else
		return formatFloat(bytes / (1024 * 1024 * 1024 * 1024)) .. " TBytes"
	end
end

-- Format the floating-point number
function formatFloat(value, size)
	return string.format("%." .. (size or 1) .. "f", value)
end

function getRootPath()
	return conf.rootPath
end

function getRootURL()
	return require('app').rootURL
end

local function getCurrentAppInfo()
	local cwd = process.cwd()
	local filename = path.join(cwd, 'package.json')
	local filedata = fs.readFileSync(filename)
	return json.parse(filedata)
end

-- 返回当前系统目标平台名称, 一般是开发板的型号或 PC 操作系统的名称
-- 因为不同平台的可执行二进制文件格式是不一样的, 所有必须严格匹配
function getSystemTarget()
	local platform = os.platform()
	local arch = os.arch()

	if (platform == 'win32') then
        return 'win'

    elseif (platform == 'darwin') then
		return 'macos'
    end

    local filename = getRootPath() .. '/package.json'
    local packageInfo = json.parse(fs.readFileSync(filename)) or {}
    local target = packageInfo.target or 'linux'
    target = target:trim()
    return target
end

-- Download the system update package file
-- callback(err, percent, data)
function downloadFile(url, callback)
	request.download(url, {}, callback)
end

-------------------------------------------------------------------------------
-- 

-- Check whether the specified file need to updated
-- @param checkInfo 需要的信息如下:
--  - rootPath 目标路径
--  - reader 
--  - index 源文件索引
-- @return 0: not need update; other: need updated
-- 
local function checkFile(checkInfo, index)

	local join   	= path.join
	local rootPath  = checkInfo.rootPath
	local reader   	= checkInfo.reader
	local filename  = reader:get_filename(index)
	if (filename == 'install.sh') then
		return 0 -- ignore `install.sh
	end

	local destname 	= join(rootPath, filename)
	local srcInfo   = reader:stat(index)

	if (reader:is_directory(index)) then
		fs.mkdirpSync(destname)
		return 0
	end
	--console.log(srcInfo)

	checkInfo.totalBytes = (checkInfo.totalBytes or 0) + srcInfo.uncomp_size
	checkInfo.total      = (checkInfo.total or 0) + 1

	-- check file size
	local destInfo 	= fs.statSync(destname)
	if (destInfo == nil) then
		return 1

	elseif (srcInfo.uncomp_size ~= destInfo.size) then 
		return 2
	end

	-- check file hash
	local srcData  = reader:extract(index)
	local destData = fs.readFileSync(destname)
	--local destHash = utils.md5(destData)
	--local srcHash  = utils.md5(srcData)
	--if (srcHash ~= destHash) then
	if (srcData ~= destData) then
		return 3
	end

	return 0
end

-- Check for files that need to be updated
-- @param checkInfo
--  - reader 
--  - rootPath 目标路径
-- @return 
-- checkInfo 会被更新的值:
--  - list 需要更新的文件列表
--  - updated 需要更新的文件数
--  - total 总共检查的文件数
--  - totalBytes 总共占用的空间大小
local function checkSystemFiles(checkInfo)
	local join    = path.join
	local reader  = checkInfo.reader

	local count = reader:get_num_files()
	for index = 1, count do
		checkInfo.index = index

		local ret = checkFile(checkInfo, index)
		--print('file', filename, ret)

		if (ret > 0) then
			checkInfo.updated = (checkInfo.updated or 0) + 1
			table.insert(checkInfo.list, index)
		end
	end
end

-- 检查系统存储空间
-- 主要是为了检查是否有足够的剩余空间用来更新固件
local function checkStorage(checkInfo)
	-- check storage size
	local lutils = require('lutils')
	local statInfo = lutils.os_statfs(checkInfo.rootPath)
	if (not statInfo) then
		return
	end

	local totalSize = statInfo.blocks * statInfo.bsize
	local freeSize  = statInfo.bfree  * statInfo.bsize
	if (totalSize > 0) then
		local percent = math.floor(freeSize * 100 / totalSize)
		print(string.format('storage: %s/%s percent: %d%%', 
			formatBytes(freeSize), 
			formatBytes(totalSize), percent))
	end
end

-- Update the specified file
-- @param checkInfo
--  - rootPath
--  - reader
-- @param index
-- 
local function updateFile(checkInfo, index)
	local join 	 	= path.join
	local rootPath 	= checkInfo.rootPath
	local reader  	= checkInfo.reader

	local filename = reader:get_filename(index)
	--print('update file: ', filename)

	-- read source file data
	local fileData 	= reader:extract(index)
	if (not fileData) then
		return -3, 'invalid source file data: ' .. filename 
	end

	-- write to a temporary file and check it
	local tempname = join(rootPath, filename .. ".tmp")
	local ret, err = fs.writeFileSync(tempname, fileData)
	if (not ret) then
		return -4, err
	end

	local destInfo = fs.statSync(tempname)
	if (destInfo == nil) then
		return -1, 'not found: ' .. filename 

	elseif (destInfo.size ~= #fileData) then
		return -2, 'invalid file size: ' .. filename 
	end

	-- rename to dest file
	local destname = join(rootPath, filename)
	os.remove(destname)
	os.rename(tempname, destname)

	print('Update file: ', filename)
	return 0
end

-- Update all Node.lua system files
-- 安装系统更新包
-- @param checkInfo 更新包
--  - reader 
--  - rootPath
-- @param files 要更新的文件列表, 保存的是文件在 reader 中的索引.
-- @param callback 更新完成后调用这个方法
-- @return 
-- checkInfo 会更新的属性:
--  - faileds 更新失败的文件数
local function updateSystemFiles(checkInfo, files, callback)
	callback = callback or noop

	files = files or checkInfo.files or {}
	print('Upgrading system "' .. checkInfo.rootPath .. '" (total ' 
		.. #files .. ' files need to update).')

	for _, index in ipairs(files) do
		local ret, err = updateFile(checkInfo, index)
		if (ret ~= 0) then
			print('ERROR.' .. index, err)
            checkInfo.faileds = (checkInfo.faileds or 0) + 1
		end
	end

	os.execute("chmod 777 " .. checkInfo.rootPath .. "/bin/*")

	callback(nil, checkInfo)
end

-- 安装系统更新包
-- @param checkInfo 更新包
--  - updateFile 
--  - rootPath
-- @param callback 更新完成后调用这个方法
-- @return
-- checkInfo 会更新的属性:
--  - list
--  - total
--  - updated
--  - totalBytes
--  - faileds
-- 
local function upgradeSystemPackage(checkInfo, callback)
	callback = callback or noop

	local filename 	= checkInfo.updateFile
	if (not filename) or (filename == '') then
		callback("Upgrade error: invalid filename")
		return
	end
	--print('update file: ' .. tostring(filename))
	print('\nInstalling package (' .. filename .. ')')

	local reader = miniz.new_reader(filename)
	if (reader == nil) then
		callback("Upgrade error: bad package bundle file", filename)
		return
	end

    local filename = path.join('package.json')
	local index, err = reader:locate_file(filename)
    if (not index) then
		callback('Upgrade error: `package.json` not found!', filename)
        return
    end

    local filedata = reader:extract(index)
    if (not filedata) then
    	callback('Upgrade error: `package.json` not found!', filename)
    	return
    end

    local packageInfo = json.parse(filedata)
    if (not packageInfo) then
    	callback('Upgrade error: `package.json` is invalid JSON format', filedata)
    	return
    end

    -- 验证安装目标平台是否一致
    if (packageInfo.target) then
		local target = getSystemTarget()
		if (target ~= packageInfo.target) then
			callback('Upgrade error: Mismatched target: local is `' .. target .. 
				'`, but the update file is `' .. tostring(packageInfo.target) .. '`')
	    	return
		end

	elseif (checkInfo.isAPP) and (packageInfo.name) then
		checkInfo.name     = packageInfo.name
		checkInfo.rootPath = path.join(checkInfo.rootPath, 'app', checkInfo.name)
	end

	checkInfo.list 		 = {}
	checkInfo.total 	 = 0
    checkInfo.updated 	 = 0
	checkInfo.totalBytes = 0
    checkInfo.faileds 	 = 0
	checkInfo.reader	 = reader

	checkSystemFiles(checkInfo)
	updateSystemFiles(checkInfo, checkInfo.list, callback)
end

local function showUpgradeResult(checkInfo)
	if (checkInfo.faileds and checkInfo.faileds > 0) then
		print(string.format('Total (%d) error has occurred!', checkInfo.faileds))
	else
		print('\nFinished\n')
	end
end

local function downloadSystemPackage(checkInfo, callback)
	callback = callback or noop

	local tmpdir = os.tmpdir or '/tmp'
	local filename = path.join(tmpdir, '/update.zip')

	-- 检查 SDK 更新包是否已下载
	local packageInfo = checkInfo.packageInfo
	--print(packageInfo.size, packageInfo.md5sum)
	if (packageInfo and packageInfo.size) then
		local filedata = fs.readFileSync(filename)
		if (filedata and #filedata == packageInfo.size) then
			local md5sum = utils.bin2hex(utils.md5(filedata))
			--print('md5sum', md5sum)

			if (md5sum == packageInfo.md5sum) then
				checkInfo.updateFile = filename
				upgradeSystemPackage(checkInfo, callback)
				return
			end
		end
	end

	-- 下载最新的 SDK 更新包
	downloadFile(checkInfo.url, function(err, percent, data, statusCode)
		if (err) then 
			print(err)
			callback(err)
			return 
		end

		if (percent <= 100) then
			print('Downloading package (' .. percent .. '%).')
		end

		if (percent ~= 200) then
			return
		end

		-- write to a temp file
		print('Done!')

		os.remove(filename)
		fs.writeFileSync(filename, data)
		checkInfo.updateFile = filename
		
		upgradeSystemPackage(checkInfo, callback)
	end)
end

-------------------------------------------------------------------------------
-- exports

function exports.check()
	local target = getSystemTarget()
	print("System type:  " .. target)

	local rootURL = ""
	if (not hostname) then
		rootURL = getRootURL()
	else
		rootURL = 'http://' .. hostname
	end

	local baseURL 	= rootURL .. '/download/cache'
	local url 		= baseURL .. '/nodelua-' .. target .. '-sdk.json'
	print('Updating system informations...')

	downloadFile(url, function(err, percent, data)
		if (err) then 
			print(err)

			fs.fileLock(lockfd, 'u')
			return

		elseif (percent ~= 200) then
			return
		end

		local packageInfo = json.parse(data)
		if (not packageInfo) or (not packageInfo.filename) then
			print("Bad package information format!")
			return
		end

		print("Done!")

		--print(data)
		--console.log(packageInfo)

		local url = baseURL .. '/' .. packageInfo.filename

		print('target:          ' .. tostring(packageInfo.target))
		print('description:     ' .. tostring(packageInfo.description))
		print('version:         ' .. tostring(packageInfo.version))
		print('mtime:           ' .. tostring(packageInfo.mtime))
		print('size:            ' .. tostring(packageInfo.size))
		print('md5sum:          ' .. tostring(packageInfo.md5sum))
		print('applications:    ' .. json.stringify(packageInfo.applications))
		
		print('Update file url: ' .. url)

	end)
end

function exports.connect(hostname, password)
	-- TODO: connect
	if (not hostname) or (not password) then
		print('\nUsage: lpm connect <hostname> <password>\n')
	end

	local deploy = conf('deploy')
	if (deploy) then

		if (hostname) then
			deploy:set('hostname', hostname)
		end

		if (password) then
			deploy:set('password', password)
		end

		deploy:commit()

		print('Current settings:')
		print('')
		print('- hostname: ' .. (deploy:get('hostname') or '-'))
		print('- password: ' .. (deploy:get('password') or '-'))
		print('')
	end
end

function exports.deploy(hostname, password)
	print("\nUsage: lpm deploy <hostname> <password>\n")

	if (not hostname) then
		local deploy = conf('deploy')
		hostname = deploy:get('hostname')
		password = password or deploy:get('password')

		if (not hostname) then
			print("Need hostname!")
			return
		end
	end

	local request = require('ext/request')

	print('Deploy device:  ' .. hostname)

	local url = 'http://' .. hostname .. ':9100/device'
	request(url, function(err, response, body)
		if (err) then print('Connect to server failed: ', err) return end

		local systemInfo = json.parse(body)
		if (not systemInfo) then
			print('invalid device info')
			return
		end

		--console.log(systemInfo)

		local device = systemInfo.device
		if (not systemInfo) then
			print('invalid device info')
			return
		end

		local target = device.target
		local version = device.version or ''
		if (not target) then
			print('invalid device target type')
			return
		end

		print('Deploy target:  ' .. target .. ', v' .. version)

		local filename = path.join(process.cwd(), 'build', 'nodelua-' .. target .. '-sdk.zip');
		print('Deploy file:    ' .. filename)

		if (not fs.existsSync(filename)) then
			print('Deploy failed:  Update file not found, please build it firist!')
			return
		end

		local filedata = fs.readFileSync(filename)
		if (not filedata) then
			print('Deploy failed:  Invalid update file!')
			return
		end

		local options = {}
		options.data = filedata

		local url = 'http://' .. hostname .. ':9100/upgrade'
		request.post(url, options, function(err, response, body)
			if (err) then print(err) return end

			local result = json.parse(body) or {}
			if (result.ret == 0) then
				print('Deploy finish!')
			else
				print('Deploy error: ' .. tostring(result.error))
			end
		end)
	end)
end

function exports.disconnect()
	local deploy = conf('deploy')
	if (deploy) then
		deploy:set('hostname', nil)
		deploy:set('password', nil)
		deploy:commit()

		print("Disconnected!")
	end
end

function exports.help()
	print([[

Node.lua packages upgrade tools

Usage:
  lpm connect [hostname] [password] Connect a device with password
  lpm deploy [hostname] [password]  Update all packages on the device
  lpm disconnect                    Disconnect the current device
  lpm install [name]                Install a application to the device
  lpm remove [name]                 Remove a application on the device
  lpm scan [timeout]                Scan devices
  lpm upgrade [name] [rootPath]     Update all packages

upgrade: 
  This command will update all the packages listed to the latest version
  If the package <name> is "all", all packages in the specified location
  (global or local) will be updated.

deploy:
  Update all packages on the device to the latest version

]])

end

function exports.remove(name)
	local appPath = path.join(path.dirname(os.tmpname()), 'app')
	local filename = path.join(appPath, name)
	os.execute("rm -rf " .. filename)

	print("removed!")
end

function exports.install(name)
	local dest = nil
	if (name == '-l') then
		dest = 'local'
		name = nil

	elseif (name == '-g') then
		dest = 'global'
		name = nil
	end

	if (not name) then
		print("\nUsage: lpm install [options] <name>\n  -l local\n  -g global\n")
	end

	if (not name) then
		local package  = getCurrentAppInfo() or {}
		--console.log(package)
		name = package.name

		if (not name) or (name == '') then
			print('missing package name!')
			return
		end
	end

	local hostname
	if (not hostname) then
		local deploy = conf('deploy')
		hostname = deploy:get('hostname')
		password = password or deploy:get('password')

		if (not hostname) then
			print("Need hostname!")
			return
		end
	end

	local request = require('ext/request')

	print('Install target:  ' .. hostname)
	print('Install APP:     ' .. name)

	local tmpdir = path.dirname(os.tmpname())
	local buildPath = path.join(tmpdir, 'packages')
	local filename = path.join(buildPath, "" .. name .. ".zip")
	print('Install file:    ' .. filename)

	if (not fs.existsSync(filename)) then
		print('Install failed:  Update file not found, please build it firist!')
		return
	end

	if (dest == 'local') then
		local tmpdir = path.dirname(os.tmpname())
		exports.installFile(filename, tmpdir)
		return
	end

	local filedata = fs.readFileSync(filename)
	if (not filedata) then
		print('Install failed:  Invalid update file!')
		return
	end

	local options = {}
	options.data = filedata

	local url = 'http://' .. hostname .. ':9100/install'
	if (dest) then
		url = url .. "?dest=" .. dest
	end
	print('Install url:    ' .. url)
	request.post(url, options, function(err, response, body)
		if (err) then print(err) return end

		local result = json.parse(body) or {}
		if (result.ret == 0) then
			print('Install finish!')
		else
			print('Install error: ' .. tostring(result.error))
		end
	end)
end


-- 安装SDK更新包
-- @param filename 要安装的文件
-- @param rootPath 要安装的路径
function exports.upgradeFile(filename, rootPath, callback)
	local checkInfo = {}
	checkInfo.updateFile = filename or '/tmp/update.zip'
	checkInfo.rootPath 	 = rootPath or getRootPath()
	upgradeSystemPackage(checkInfo, callback)
	--showUpgradeResult(checkInfo)
	return checkInfo
end

-- 安装应用安装包
-- @param filename 要安装的文件
-- @param rootPath 要安装的路径
function exports.installFile(filename, rootPath, callback)
	local checkInfo = {}
	checkInfo.updateFile = filename or '/tmp/install.zip'
	checkInfo.rootPath 	 = rootPath or getRootPath()
	checkInfo.isAPP      = true
	upgradeSystemPackage(checkInfo, callback)
	--showUpgradeResult(checkInfo)
	return checkInfo
end

--[[
更新系统


--]]
function exports.upgrade(source, rootPath)
	if (not source) then
		exports.help()
		return

	elseif (source == 'check') then
		exports.check()
		return
	end

	rootPath = rootPath or getRootPath()

	local filename1 = path.join(rootPath, 'lua/lnode')
	local filename2 = path.join(rootPath, 'src')
	if (fs.existsSync(filename1) or fs.existsSync(filename2)) then
		print('The "' .. rootPath .. '" is a development path.')
		print('You can not update the system in development mode.\n')
		return
	end

	local tmpdir = os.tmpdir or '/tmp'

	-- 检查是否有另一个进程正在更新系统
	local lockname = path.join(tmpdir, '/update.lock')
	local lockfd = fs.openSync(lockname, 'w+')
	local ret = fs.fileLock(lockfd, 'w')
	if (ret == -1) then
		print('The system update is lock!')
		return
	end

	print("Upgrade path: " .. rootPath)

	-- function(filename, rootPath)
	if source and (source:startsWith("/")) then
		local checkInfo = {}
		checkInfo.updateFile = source
		checkInfo.rootPath   = rootPath

		upgradeSystemPackage(checkInfo, function(err)
			if (err) then print(err) end

			fs.fileLock(lockfd, 'u')

			showUpgradeResult(checkInfo)
		end)

		return checkInfo
	end

	local target = getSystemTarget()
	print("System type: " .. target)

	local rootURL = ""
	if (not hostname) then
		rootURL = getRootURL()
	else
		rootURL = 'http://' .. hostname
	end

	local baseURL 	= rootURL .. '/download/dist/' .. target
	local url 		= baseURL .. '/nodelua-' .. target .. '-sdk.json'
	print('Updating system informations...')

	downloadFile(url, function(err, percent, data)
		if (err) then 
			print(err)

			fs.fileLock(lockfd, 'u')
			return

		elseif (percent ~= 200) then
			return
		end

		local packageInfo = json.parse(data)
		if (not packageInfo) or (not packageInfo.filename) then
			print("Bad package information format!")
			return
		end

		print("Done!")

		--print(data)
		--console.log(packageInfo)
		local url = baseURL .. '/' .. packageInfo.filename
		print('Package url: ' .. url)

		local checkInfo = {}
		checkInfo.url = url
		checkInfo.packageInfo = packageInfo
		checkInfo.rootPath = rootPath
		downloadSystemPackage(checkInfo, function(err)
			if (err) then print(err) end

			fs.fileLock(lockfd, 'u')

			showUpgradeResult(checkInfo)
		end)
	end)
end

return exports
