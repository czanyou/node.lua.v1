--[[

Copyright 2016 The Node.lua Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS-IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

--]]

local core   	= require('core')
local fs     	= require('fs')
local json   	= require('json')
local path   	= require('path')
local utils     = require('utils')
local conf      = require('ext/conf')

-------------------------------------------------------------------------------
-- misc

local function getRootPath()
	return conf.rootPath
end

local function _loadLuaFile(filename, ...)
	local script, err = loadfile(filename)
	if (err) then
		error(err)
		return -4, err
	end

	_G.arg = table.pack(...)
	return 0, script(...)
end

-------------------------------------------------------------------------------
-- exports

local exports = {}
exports.meta  = {}
setmetatable(exports, exports.meta)

exports.rootPath = getRootPath()
exports.rootURL  = "http://node.sae-sz.com"

-------------------------------------------------------------------------------
-- Application Manager

local ApplicationManager = core.Emitter:extend()
exports.ApplicationManager = ApplicationManager

-- 初始化方法/构造函数
function ApplicationManager:initialize()
    self.rootPath   = exports.rootPath
    self.packages   = {}
end

function ApplicationManager:execute(name, ...)
	if (not name) then
		return self:executeCurrentApplication(...)
	end

	return self:executeApplication(name, ...)
end

function ApplicationManager:executeApplication(name, action, ...)
	if (not name) then
		return -1
	end

	local appPath = path.join(path.dirname(os.tmpname()), 'app')
	local basePath = path.join(appPath, name)
	if (not fs.existsSync(basePath)) then
		appPath  = self:getAppPath()
		basePath = path.join(appPath, name)
		if (not fs.existsSync(basePath)) then
			self:onError('"' .. basePath .. '" not exists!')
			return -2
		end
	end

	if (action == 'info') then
		print(name .. ': ')
		console.log(self:localApplicationInfo(basePath) or '')
		return 0
	end

	local filename = path.join(basePath, 'init.lua')
	if (not fs.existsSync(filename)) then
		self:onError('"' .. filename .. '" not exists!')
		return -3
	end

    return _loadLuaFile(filename, action, ...)
end

function ApplicationManager:daemon(name, ...)
	if (not name) then
		print('daemon', 'name expead!')
		return -1
	end

	local appPath  = self:getAppPath()
	local basePath = path.join(appPath, name)
	if (not fs.existsSync(basePath)) then
		self:onError('"' .. basePath .. '" not exists!')
		return -2
	end

	if (action == 'info') then
		print(name .. ': ')
		console.log(self:localApplicationInfo(basePath) or '')
		return 0
	end	

	local filename = path.join(basePath, 'init.lua')
	if (not fs.existsSync(filename)) then
		self:onError('"' .. filename .. '" not exists!')
		return -3
	end

    local cmdline  = "lnode -d " .. filename .. " start"
	print('daemon: ', cmdline)
	os.execute(cmdline)
end

function ApplicationManager:executeCurrentApplication(...)
	local pwd = process.cwd()

	local filename = path.join(pwd, "init.lua")
	if (not fs.existsSync(filename)) then
		self:onError('`./init.lua` not exists!')
		return -3
	end

	return _loadLuaFile(filename, ...)
end

function ApplicationManager:getAppPath()
	local appPath = path.join(self.rootPath, "app")
	if (not fs.existsSync(appPath)) then
		appPath = path.join(path.dirname(self.rootPath), "app")
	end

	return appPath
end

-- 显示所有已安装的包的信息
function ApplicationManager:list(name)
	local appPath = path.join(self:getAppPath())

	if (name == '-l') then
		name = nil
		appPath = path.join(path.dirname(os.tmpname()), 'app')
	end

	if (name) then
		print(tostring(name) .. ': ')
		self:execute(name, 'info')
		return
	end

	
	local files = nil
	if (fs.existsSync(appPath)) then
		files = fs.readdirSync(appPath)
	end

	local cols = { 12, 12, 48 }
	local color = utils.color

	local index = 0
	exports.tableDivision(cols)
	exports.tableLine(cols, 'Name', 'Version', 'Description')
	exports.tableDivision(cols, '=')

	if (files) then
		for i = 1, #files do
			local file = files[i]
			local filename  = path.join(appPath, file)
			local name 		= path.basename(file)
			local info 		= self:localApplicationInfo(filename)
			if (info) then
				local version 	= info.version  or ''
				local desc      = info.description or ''

				exports.tableLine(cols, name, version, desc)
				index = index + 1
			end
		end
	end

	exports.tableDivision(cols)
    print(string.format("+ total %s applications (%s).", 
        index, appPath))
end

function ApplicationManager:localApplicationInfo(basePath)
	local filename = path.join(basePath, "package.json")
	local data = fs.readFileSync(filename)
	return data and json.parse(data)
end

-- 显示错误信息
function ApplicationManager:onError(errorInfo, ...)
	print('Error:', utils.color("err"), tostring(errorInfo), utils.color(), ...)

end

-------------------------------------------------------------------------------
-- profile

local _profile = nil

local function loadProfile()
    if (_profile) then
        return _profile
    end

	_profile = conf('user')
    return _profile
end

-- 删除指定名称的配置参数项的值
-- @param name {String}
function exports.del(name)
    if (not name) then
        return
    end

	local profile = loadProfile()
	if (profile) and (profile:get(name)) then
		profile:set(name, nil)
		profile:commit()
	end
end

function exports.daemon(filename)
	local filename = utils.filename(3)
    if (not filename) then
        return
    end
    --print(filename)

	local cmdline  = "lnode -d " .. filename .. " start"
	print('daemon: ', cmdline)
	os.execute(cmdline)
end

-- 打印指定名称的配置参数项的值
-- @param name {String}
function exports.get(name)
	if (not name) then
        return
    end

	local profile = loadProfile()
    if (profile) then
		return profile:get(name)
	end
end

function exports.main(handler, action, ...)
    local method = handler[action]
    if (not method) then
        method = handler.help
    end

    if (method) then
        method(...)
	end
end

function exports.rpc(port, handler)
    if (port and handler) then
        local rpc = require('ext/rpc')
        exports.server = rpc.server(port, handler)
    end
end

-- 设置指定名称的配置参数项的值
-- @param name {String|Object}
-- @param value {String|Number|Boolean}
function exports.set(name, value)
	if (not name) then
		return
	end

	local profile = loadProfile()
    if (not profile) then
        return
    end

    if (type(name) == 'table') then
        local count = 0
        for k, v in pairs(name) do
            local oldValue = profile:get(k)
            --print(k, v, oldValue)

            if (not oldValue) or (v ~= oldValue) then
                profile:set(k, v)

                count = count + 1
            end
        end

        if (count > 0) then
            profile:commit()
        end

    else 
    	if (not name) or (not value) then
            return
        end

        local oldValue = profile:get(name)
        if (not oldValue) or (value ~= oldValue) then
            profile:set(name, value)
            profile:commit()
        end
    end
end

-- 为指定的文本尾部添加占位空白, 方便对齐显示
function exports.paddingString(text, min, max)
	text = tostring(text)
	local len = #text
    if (max and len > max) then
        return text:sub(1, max)
    end

	if (len < min) then
		return text .. string.rep(' ', min - len)
	end

	return text
end

-- 显示表格分隔线
function exports.tableDivision(cols, ch)
	ch = ch or '-'

	local line = {}
	for i = 1, #cols do
		local count = math.max(0, cols[i] - 2)
		line[#line + 1] = ' '
		line[#line + 1] = string.rep(ch, count)
	end

	print(table.concat(line))
end

-- 显示表格的标题头
function exports.tableHeader(cols, title)
	local total = 0
	for i = 1, #cols do
		total = total + cols[i] + 1
	end

	local line = ' ' .. exports.paddingString(title, total - 3) .. ' '
	print(line)
end

-- 显示表格的一行
function exports.tableLine(cols, ...)
	local values = { ... }
	local line = {}

	for i = 1, #cols do
        local colWidth = cols[i] - 2
		line[#line + 1] = ' '
		line[#line + 1] = exports.paddingString(values[i], colWidth, colWidth)
	end

	print(table.concat(line))
end

-- 解析 exports 的 package.json 文件, 并显示相关的使用说明信息. 
function exports.usage(dirname)
    local fs    = require('fs')
    local json  = require('json')

    local data      = fs.readFileSync(dirname .. '/package.json')
    local package   = json.parse(data) or {}

    local color  = utils.color
	local quotes = color('quotes')
	local desc 	 = color('braces')
	local normal = color()

    -- Name
    print(quotes, '\nusage: lpm ' .. tostring(package.name) .. ' <command> [args]\n', normal)

    -- Description
    if (package.description) then
        print(package.description, '\n')
    end

	local printList = function(name, list)
		if (not list) then
			return
		end

        print(name .. ':\n')
		for _, item in ipairs(list) do
			print('- ' ..  exports.paddingString(tostring(item.name), 24), 
				desc .. tostring(item.desc), normal)
		end

		print('')
	end

    printList('Settings', 			package.settings)
    printList('IPC command', 		package.rpc)
    printList('available command', 	package.commands)
end

-- Format the bytes number to human-readable string
function exports.formatBytes(bytes)
	if (bytes < 1024) then
		return bytes .. " Bytes"

	elseif (bytes < 1024 * 1024) then
		return exports.formatFloat(bytes / 1024) .. " KBytes"

	elseif (bytes < 1024 * 1024 * 1024) then
		return exports.formatFloat(bytes / (1024 * 1024)) .. " MBytes"

	elseif (bytes < 1024 * 1024 * 1024 * 1024) then
		return exports.formatFloat(bytes / (1024 * 1024 * 1024)) .. " GBytes"

	else
		return exports.formatFloat(bytes / (1024 * 1024 * 1024 * 1024)) .. " TBytes"
	end
end

-- Format the floating-point number
function exports.formatFloat(value, size)
	return string.format("%." .. (size or 1) .. "f", value)
end


function exports.manager()
    return ApplicationManager:new()
end

exports.meta.__call = function(self, handler)
    exports.main(handler, table.unpack(arg))
end

return exports
